﻿[CmdletBinding()]
Param(
    [Parameter(ParameterSetName='Execution')]$ForestName,
    [Parameter(ParameterSetName='Execution')]$DomainNames,
    [Parameter(ParameterSetName='Execution')][String]$TenantId,
    [Parameter(ParameterSetName='Execution')][String]$TenantAppId,
    [Parameter(ParameterSetName='Execution')][String]$TenantAppSecret,
    [Parameter(Mandatory=$False,ParameterSetName='Execution')]$StartAttackWindow,
    [Parameter(Mandatory=$False,ParameterSetName='Execution')]$EndAttackWindow,
    [Parameter(ParameterSetName='Metadata',Mandatory)][switch]$Metadata
)

$Global:self = @{
    ID = 169
    UUID = '7b1b04d3-216b-4031-9657-679443ab3c51'
    Version = '1.0.97827'
    CategoryID = 6
    ShortName = 'SI000169'
    Name = 'Users can create security groups'
    ScriptName = 'AAD_UsersCanCreateSecurityGroups'
    Description = 'This indicator checks if normal users can create security groups. Required permissions: Policy.Read.All'
    Weight = 4
    Severity = 'Informational'
    
    LikelihoodOfCompromise = 'Users should not be allowed to create security groups. This is enabled by default in Azure AD and should be disabled.'
    ResultMessage = 'Any user can create security groups'
    Remediation = 'To enhance security practices, it is advisable to disable the feature that allows users to create security groups in Azure AD.
      Follow these steps to disable the setting:<br><br>
      Open the Azure Active Directory <a href="https://portal.azure.com" target="_blank">portal.</a><br>
      Navigate to the "Groups" section.<br>
      Access the "General" settings associated with groups.<br>
      Locate the option labeled "Users can create security groups in Azure portals, API, or PowerShell."<br>
      Switch the option to "No" to deactivate users'' ability to create security groups.<br>
      It is important to note that if users require the ability to create security groups, they should be assigned a valid role that grants them the necessary permissions. Disabling this option does not impact the ability to create Microsoft 365 (M365) groups, which possess distinct permissions and functionalities.<br>
      Implementing this change contributes to a more secure and organized Azure AD environment, reducing the potential risks associated with unauthorized group creations and potential security vulnerabilities.'
    Types = @('IoE')
    DataSources = @('AAD.GraphAPI')
    Targets = @('AAD')
    Permissions = @('AAD.GraphAPI/Policy.Read.All')
    SecurityFrameworks = @(
        @{ Name = 'MITRE ATT&CK'; Tags = @('Persistence', 'Privilege Escalation') },
        @{ Name = 'MITRE D3FEND'; Tags = @('Model - Access Modeling') }
    )
    Products = @(
        @{ Name = 'DSP'; MinVersion = '3.6'; MaxVersion = '10'; Licenses = @('DSP-I-AAD') },
        @{ Name = 'PK'; MinVersion = '1.5'; MaxVersion = '10'; Licenses = @('Community', 'Post-Breach', 'BPIR') }
    )
    Selected = 1
}
if($Metadata){ return $self | ConvertTo-Json -Depth 8 -Compress }

Import-Module -Name Semperis-Lib
<#
REFERENCE:
https://docs.microsoft.com/en-us/graph/api/authorizationpolicy-get?view=graph-rest-1.0

REQUIRED APP ROLE ACCESS
- READ AUTHORIZATION POLICY:  Policy.Read.All
#>

try {
    if ($PSBoundParameters['ForestName'] -and $PSBoundParameters['DomainNames']) {
        $ForestName = $ForestName.ToLower()
        $DomainNames = ConvertTo-Lowercase -DomainNames $DomainNames
    }
    $res = New-Object Semperis.PSSecurityIndicatorResult.SecurityIndicatorResult

    If (-not $TenantAppSecret) {
        $res.Status = 'NotRelevant'
        $res.ResultMessage = 'Azure AD not connected. Please complete the Identity analytics server (Hybrid server) setup.'
        return $res
    }

    $getToken = @{
        TenantId = $TenantId
        TenantAppId = $TenantAppId
        TenantAppSecret = $TenantAppSecret
    }

    $graphAccess = Get-GraphApiToken @getToken

    $getAuthorizationPolicies = @{
        Uri = "https://graph.microsoft.com/v1.0/policies/authorizationPolicy"
        AccessToken = $graphAccess
    }

    try {
        $authorizationPolicies = Invoke-GraphApiRequest @getAuthorizationPolicies
    }
    catch {
        return $_ | ConvertTo-GraphApiErrorResult -RequiredPrivileges 'Read Authorization Policy' -TenantAppId $TenantAppId -AccessToken $graphAccess
    }

    if ($authorizationPolicies.defaultUserRolePermissions.allowedToCreateSecurityGroups -eq $true) {
        $res.Score = 0
        $res.ResultMessage = $self.ResultMessage
        $res.Remediation = $self.Remediation
        $res.Status = [Semperis.PSSecurityIndicatorResult.ScriptStatus]"Failed"

    }
    else {
        $res.Score = 100
        $res.ResultMessage = "No evidence of exposure."
        $res.Remediation = "None"
        $res.Status = [Semperis.PSSecurityIndicatorResult.ScriptStatus]"Pass"
    }
}
catch {
    return ConvertTo-ErrorResult $_
}
return $res

# SIG # Begin signature block
# MIItlwYJKoZIhvcNAQcCoIItiDCCLYQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCzrT6jo+ioiRoT
# 82TdRiKluNKirzfRYBSHIPmLUy1GsqCCJrcwggWNMIIEdaADAgECAhAOmxiO+dAt
# 5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBa
# Fw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3E
# MB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKy
# unWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsF
# xl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU1
# 5zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJB
# MtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObUR
# WBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6
# nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxB
# YKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5S
# UUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+x
# q4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIB
# NjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMC
# AYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0Nc
# Vec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnov
# Lbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65Zy
# oUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFW
# juyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPF
# mCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9z
# twGpn1eqXijiuZQwggWiMIIEiqADAgECAhB4AxhCRXCKQc9vAbjutKlUMA0GCSqG
# SIb3DQEBDAUAMEwxIDAeBgNVBAsTF0dsb2JhbFNpZ24gUm9vdCBDQSAtIFIzMRMw
# EQYDVQQKEwpHbG9iYWxTaWduMRMwEQYDVQQDEwpHbG9iYWxTaWduMB4XDTIwMDcy
# ODAwMDAwMFoXDTI5MDMxODAwMDAwMFowUzELMAkGA1UEBhMCQkUxGTAXBgNVBAoT
# EEdsb2JhbFNpZ24gbnYtc2ExKTAnBgNVBAMTIEdsb2JhbFNpZ24gQ29kZSBTaWdu
# aW5nIFJvb3QgUjQ1MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAti3F
# MN166KuQPQNysDpLmRZhsuX/pWcdNxzlfuyTg6qE9aNDm5hFirhjV12bAIgEJen4
# aJJLgthLyUoD86h/ao+KYSe9oUTQ/fU/IsKjT5GNswWyKIKRXftZiAULlwbCmPgs
# pzMk7lA6QczwoLB7HU3SqFg4lunf+RuRu4sQLNLHQx2iCXShgK975jMKDFlrjrz0
# q1qXe3+uVfuE8ID+hEzX4rq9xHWhb71hEHREspgH4nSr/2jcbCY+6R/l4ASHrTDT
# DI0DfFW4FnBcJHggJetnZ4iruk40mGtwEd44ytS+ocCc4d8eAgHYO+FnQ4S2z/x0
# ty+Eo7+6CTc9Z2yxRVwZYatBg/WsHet3DUZHc86/vZWV7Z0riBD++ljop1fhs8+o
# WukHJZsSxJ6Acj2T3IyU3ztE5iaA/NLDA/CMDNJF1i7nj5ie5gTuQm5nfkIWcWLn
# BPlgxmShtpyBIU4rxm1olIbGmXRzZzF6kfLUjHlufKa7fkZvTcWFEivPmiJECKiF
# N84HYVcGFxIkwMQxc6GYNVdHfhA6RdktpFGQmKmgBzfEZRqqHGsWd/enl+w/GTCZ
# bzH76kCy59LE+snQ8FB2dFn6jW0XMr746X4D9OeHdZrUSpEshQMTAitCgPKJajbP
# yEygzp74y42tFqfT3tWbGKfGkjrxgmPxLg4kZN8CAwEAAaOCAXcwggFzMA4GA1Ud
# DwEB/wQEAwIBhjATBgNVHSUEDDAKBggrBgEFBQcDAzAPBgNVHRMBAf8EBTADAQH/
# MB0GA1UdDgQWBBQfAL9GgAr8eDm3pbRD2VZQu86WOzAfBgNVHSMEGDAWgBSP8Et/
# qC5FJK5NUPpjmove4t0bvDB6BggrBgEFBQcBAQRuMGwwLQYIKwYBBQUHMAGGIWh0
# dHA6Ly9vY3NwLmdsb2JhbHNpZ24uY29tL3Jvb3RyMzA7BggrBgEFBQcwAoYvaHR0
# cDovL3NlY3VyZS5nbG9iYWxzaWduLmNvbS9jYWNlcnQvcm9vdC1yMy5jcnQwNgYD
# VR0fBC8wLTAroCmgJ4YlaHR0cDovL2NybC5nbG9iYWxzaWduLmNvbS9yb290LXIz
# LmNybDBHBgNVHSAEQDA+MDwGBFUdIAAwNDAyBggrBgEFBQcCARYmaHR0cHM6Ly93
# d3cuZ2xvYmFsc2lnbi5jb20vcmVwb3NpdG9yeS8wDQYJKoZIhvcNAQEMBQADggEB
# AKz3zBWLMHmoHQsoiBkJ1xx//oa9e1ozbg1nDnti2eEYXLC9E10dI645UHY3qkT9
# XwEjWYZWTMytvGQTFDCkIKjgP+icctx+89gMI7qoLao89uyfhzEHZfU5p1GCdeHy
# L5f20eFlloNk/qEdUfu1JJv10ndpvIUsXPpYd9Gup7EL4tZ3u6m0NEqpbz308w2V
# Xeb5ekWwJRcxLtv3D2jmgx+p9+XUnZiM02FLL8Mofnrekw60faAKbZLEtGY/fadY
# 7qz37MMIAas4/AocqcWXsojICQIZ9lyaGvFNbDDUswarAGBIDXirzxetkpNiIHd1
# bL3IMrTcTevZ38GQlim9wX8wggauMIIElqADAgECAhAHNje3JFR82Ees/ShmKl5b
# MA0GCSqGSIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMjAzMjMwMDAwMDBaFw0zNzAzMjIyMzU5
# NTlaMGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkG
# A1UEAxMyRGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3Rh
# bXBpbmcgQ0EwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDGhjUGSbPB
# PXJJUVXHJQPE8pE3qZdRodbSg9GeTKJtoLDMg/la9hGhRBVCX6SI82j6ffOciQt/
# nR+eDzMfUBMLJnOWbfhXqAJ9/UO0hNoR8XOxs+4rgISKIhjf69o9xBd/qxkrPkLc
# Z47qUT3w1lbU5ygt69OxtXXnHwZljZQp09nsad/ZkIdGAHvbREGJ3HxqV3rwN3mf
# XazL6IRktFLydkf3YYMZ3V+0VAshaG43IbtArF+y3kp9zvU5EmfvDqVjbOSmxR3N
# Ng1c1eYbqMFkdECnwHLFuk4fsbVYTXn+149zk6wsOeKlSNbwsDETqVcplicu9Yem
# j052FVUmcJgmf6AaRyBD40NjgHt1biclkJg6OBGz9vae5jtb7IHeIhTZgirHkr+g
# 3uM+onP65x9abJTyUpURK1h0QCirc0PO30qhHGs4xSnzyqqWc0Jon7ZGs506o9UD
# 4L/wojzKQtwYSH8UNM/STKvvmz3+DrhkKvp1KCRB7UK/BZxmSVJQ9FHzNklNiyDS
# LFc1eSuo80VgvCONWPfcYd6T/jnA+bIwpUzX6ZhKWD7TA4j+s4/TXkt2ElGTyYwM
# O1uKIqjBJgj5FBASA31fI7tk42PgpuE+9sJ0sj8eCXbsq11GdeJgo1gJASgADoRU
# 7s7pXcheMBK9Rp6103a50g5rmQzSM7TNsQIDAQABo4IBXTCCAVkwEgYDVR0TAQH/
# BAgwBgEB/wIBADAdBgNVHQ4EFgQUuhbZbU2FL3MpdpovdYxqII+eyG8wHwYDVR0j
# BBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0
# cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0
# cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8E
# PDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkUm9vdEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEw
# DQYJKoZIhvcNAQELBQADggIBAH1ZjsCTtm+YqUQiAX5m1tghQuGwGC4QTRPPMFPO
# vxj7x1Bd4ksp+3CKDaopafxpwc8dB+k+YMjYC+VcW9dth/qEICU0MWfNthKWb8RQ
# TGIdDAiCqBa9qVbPFXONASIlzpVpP0d3+3J0FNf/q0+KLHqrhc1DX+1gtqpPkWae
# LJ7giqzl/Yy8ZCaHbJK9nXzQcAp876i8dU+6WvepELJd6f8oVInw1YpxdmXazPBy
# oyP6wCeCRK6ZJxurJB4mwbfeKuv2nrF5mYGjVoarCkXJ38SNoOeY+/umnXKvxMfB
# wWpx2cYTgAnEtp/Nh4cku0+jSbl3ZpHxcpzpSwJSpzd+k1OsOx0ISQ+UzTl63f8l
# Y5knLD0/a6fxZsNBzU+2QJshIUDQtxMkzdwdeDrknq3lNHGS1yZr5Dhzq6YBT70/
# O3itTK37xJV77QpfMzmHQXh6OOmc4d0j/R0o08f56PGYX/sr2H7yRp11LB4nLCbb
# bxV7HhmLNriT1ObyF5lZynDwN7+YAN8gFk8n+2BnFqFmut1VwDophrCYoCvtlUG3
# OtUVmDG0YgkPCr2B2RP+v6TR81fZvAT6gt4y3wSJ8ADNXcL50CN/AAvkdgIm2fBl
# dkKmKYcJRyvmfxqkhQ/8mJb2VVQrH4D6wPIOK+XW+6kvRBVK5xMOHds3OBqhK/bt
# 1nz8MIIGwDCCBKigAwIBAgIQDE1pckuU+jwqSj0pB4A9WjANBgkqhkiG9w0BAQsF
# ADBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNV
# BAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1w
# aW5nIENBMB4XDTIyMDkyMTAwMDAwMFoXDTMzMTEyMTIzNTk1OVowRjELMAkGA1UE
# BhMCVVMxETAPBgNVBAoTCERpZ2lDZXJ0MSQwIgYDVQQDExtEaWdpQ2VydCBUaW1l
# c3RhbXAgMjAyMiAtIDIwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDP
# 7KUmOsap8mu7jcENmtuh6BSFdDMaJqzQHFUeHjZtvJJVDGH0nQl3PRWWCC9rZKT9
# BoMW15GSOBwxApb7crGXOlWvM+xhiummKNuQY1y9iVPgOi2Mh0KuJqTku3h4uXoW
# 4VbGwLpkU7sqFudQSLuIaQyIxvG+4C99O7HKU41Agx7ny3JJKB5MgB6FVueF7fJh
# vKo6B332q27lZt3iXPUv7Y3UTZWEaOOAy2p50dIQkUYp6z4m8rSMzUy5Zsi7qlA4
# DeWMlF0ZWr/1e0BubxaompyVR4aFeT4MXmaMGgokvpyq0py2909ueMQoP6McD1AG
# N7oI2TWmtR7aeFgdOej4TJEQln5N4d3CraV++C0bH+wrRhijGfY59/XBT3EuiQMR
# oku7mL/6T+R7Nu8GRORV/zbq5Xwx5/PCUsTmFntafqUlc9vAapkhLWPlWfVNL5Af
# J7fSqxTlOGaHUQhr+1NDOdBk+lbP4PQK5hRtZHi7mP2Uw3Mh8y/CLiDXgazT8QfU
# 4b3ZXUtuMZQpi+ZBpGWUwFjl5S4pkKa3YWT62SBsGFFguqaBDwklU/G/O+mrBw5q
# BzliGcnWhX8T2Y15z2LF7OF7ucxnEweawXjtxojIsG4yeccLWYONxu71LHx7jstk
# ifGxxLjnU15fVdJ9GSlZA076XepFcxyEftfO4tQ6dwIDAQABo4IBizCCAYcwDgYD
# VR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaA
# FLoW2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBRiit7QYfyPMRTtlwvNPSqU
# FN9SnDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3Js
# MIGQBggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0Eu
# Y3J0MA0GCSqGSIb3DQEBCwUAA4ICAQBVqioa80bzeFc3MPx140/WhSPx/PmVOZsl
# 5vdyipjDd9Rk/BX7NsJJUSx4iGNVCUY5APxp1MqbKfujP8DJAJsTHbCYidx48s18
# hc1Tna9i4mFmoxQqRYdKmEIrUPwbtZ4IMAn65C3XCYl5+QnmiM59G7hqopvBU2AJ
# 6KO4ndetHxy47JhB8PYOgPvk/9+dEKfrALpfSo8aOlK06r8JSRU1NlmaD1TSsht/
# fl4JrXZUinRtytIFZyt26/+YsiaVOBmIRBTlClmia+ciPkQh0j8cwJvtfEiy2JIM
# kU88ZpSvXQJT657inuTTH4YBZJwAwuladHUNPeF5iL8cAZfJGSOA1zZaX5YWsWMM
# xkZAO85dNdRZPkOaGK7DycvD+5sTX2q1x+DzBcNZ3ydiK95ByVO5/zQQZ/YmMph7
# /lxClIGUgp2sCovGSxVK05iQRWAzgOAj3vgDpPZFR+XOuANCR+hBNnF3rf2i6Jd0
# Ti7aHh2MWsgemtXC8MYiqE+bvdgcmlHEL5r2X6cnl7qWLoVXwGDneFZ/au/ClZpL
# EQLIgpzJGgV8unG1TnqZbPTontRamMifv427GFxD9dAq6OJi7ngE273R+1sKqHB+
# 8JeEeOMIA11HLGOoJTiXAdI/Otrl5fbmm9x+LMz/F0xNAKLY1gEOuIvu5uByVYks
# Jxlh9ncBjDCCBuYwggTOoAMCAQICEHe9DgOhtwj4VKsGchDZBEcwDQYJKoZIhvcN
# AQELBQAwUzELMAkGA1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2Ex
# KTAnBgNVBAMTIEdsb2JhbFNpZ24gQ29kZSBTaWduaW5nIFJvb3QgUjQ1MB4XDTIw
# MDcyODAwMDAwMFoXDTMwMDcyODAwMDAwMFowWTELMAkGA1UEBhMCQkUxGTAXBgNV
# BAoTEEdsb2JhbFNpZ24gbnYtc2ExLzAtBgNVBAMTJkdsb2JhbFNpZ24gR0NDIFI0
# NSBDb2RlU2lnbmluZyBDQSAyMDIwMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEA1kJN+eNPxiP0bB2BpjD3SD3P0OWN5SAilgdENV0Gzw8dcGDmJlT6UyNg
# AqhfAgL3jsluPal4Bb2O9U8ZJJl8zxEWmx97a9Kje2hld6vYsSw/03IGMlxbrFBn
# LCVNVgY2/MFiTH19hhaVml1UulDQsH+iRBnp1m5sPhPCnxHUXzRbUWgxYwr4W9De
# ullfMa+JaDhAPgjoU2dOY7Yhju/djYVBVZ4cvDfclaDEcacfG6VJbgogWX6Jo1gV
# lwAlad/ewmpQZU5T+2uhnxgeig5fVF694FvP8gwE0t4IoRAm97Lzei7CjpbBP86l
# 2vRZKIw3ZaExlguOpHZ3FUmEZoIl50MKd1KxmVFC/6Gy3ZzS3BjZwYapQB1Bl2KG
# vKj/osdjFwb9Zno2lAEgiXgfkPR7qVJOak9UBiqAr57HUEL6ZQrjAfSxbqwOqOOB
# Gag4yJ4DKIakdKdHlX5yWip7FWocxGnmsL5AGZnL0n1VTiKcEOChW8OzLnqLxN7x
# Sx+MKHkwRX9sE7Y9LP8tSooq7CgPLcrUnJiKSm1aNiwv37rL4kFKCHcYiK01YZQS
# 86Ry6+42nqdRJ5E896IazPyH5ZfhUYdp6SLMg8C3D0VsB+FDT9SMSs7PY7G1pBB6
# +Q0MKLBrNP4haCdv7Pj6JoRbdULNiSZ5WZ1rq2NxYpAlDQgg8f8CAwEAAaOCAa4w
# ggGqMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggrBgEFBQcDAzASBgNVHRMB
# Af8ECDAGAQH/AgEAMB0GA1UdDgQWBBTas43AJJCja3fTDKBZ3SFnZHYLeDAfBgNV
# HSMEGDAWgBQfAL9GgAr8eDm3pbRD2VZQu86WOzCBkwYIKwYBBQUHAQEEgYYwgYMw
# OQYIKwYBBQUHMAGGLWh0dHA6Ly9vY3NwLmdsb2JhbHNpZ24uY29tL2NvZGVzaWdu
# aW5ncm9vdHI0NTBGBggrBgEFBQcwAoY6aHR0cDovL3NlY3VyZS5nbG9iYWxzaWdu
# LmNvbS9jYWNlcnQvY29kZXNpZ25pbmdyb290cjQ1LmNydDBBBgNVHR8EOjA4MDag
# NKAyhjBodHRwOi8vY3JsLmdsb2JhbHNpZ24uY29tL2NvZGVzaWduaW5ncm9vdHI0
# NS5jcmwwVgYDVR0gBE8wTTBBBgkrBgEEAaAyATIwNDAyBggrBgEFBQcCARYmaHR0
# cHM6Ly93d3cuZ2xvYmFsc2lnbi5jb20vcmVwb3NpdG9yeS8wCAYGZ4EMAQQBMA0G
# CSqGSIb3DQEBCwUAA4ICAQAIiHImxq/6rF8GwKqMkNrQssCil/9uEzIWVP0+9DAR
# n4+Y+ZtS3fKiFu7ZeJWmmnxhuAS1+OvL9GERM/ZlJbcRQovYaW7H/5W0gUOpfq6/
# gtZNzBGjg3FqEF4ZBafnbH9W9Khcw04JrVlruPl+pS64/N4OwqD7sATUExvHJ6m5
# qi0xO89GTJ3rTOy8Lpzxh6N/OGlfQUBn9lN96kHvjj37qdQROEbfPOv2zSK9E83w
# 4eblM6C+POR41RvMIPIwc7AiHPaE1ptcAALhKFJL/xJLQOrusBoGBp6E5ufw24RG
# +3PZK0K2yVc0xxbApushuaoO9/7byuu8F8u4Z+vjPk/bqZSGZFXJCQrA2QRxShFL
# WmTDvHh4rUxHJmUHmdXNNmChM1Oz9nsq1YlAPHGlq/iZWf3jm5JL3QW9Cwx4BivP
# U9i9EppbJ4aFP5G+4HiAc1Tfpx1nK2q2rk2JgCQIUnBQ8wH/RK4vmuDhSQjh4VvX
# ONGeCoqdlCebyqO52+I2auNvuVhi4DZ4NgH6waeJeiZTo1y70rLristjCC/+HvNW
# KeI1m9j/6aW9bUtZLIksL1K7tSmQ2kNHvHLdvNm/gMHcsKu0Sx1YNjdk65vhhRea
# KaL95gjSkv+g+Hzh6afRMI5fJlArx6Lil3eK79hNPibrmUBg8zxnDLYIcik1U4E0
# 3DCCBxwwggUEoAMCAQICDElF7GllQBbooYM+/DANBgkqhkiG9w0BAQsFADBZMQsw
# CQYDVQQGEwJCRTEZMBcGA1UEChMQR2xvYmFsU2lnbiBudi1zYTEvMC0GA1UEAxMm
# R2xvYmFsU2lnbiBHQ0MgUjQ1IENvZGVTaWduaW5nIENBIDIwMjAwHhcNMjIwMzAy
# MTE0ODM5WhcNMjQwNjE0MTQzMDQ0WjCBiTELMAkGA1UEBhMCVVMxETAPBgNVBAgT
# CE5ldyBZb3JrMREwDwYDVQQHEwhOZXcgWW9yazEWMBQGA1UEChMNU0VNUEVSSVMg
# SU5DLjEWMBQGA1UEAxMNU0VNUEVSSVMgSU5DLjEkMCIGCSqGSIb3DQEJARYVY29k
# ZXNpZ25Ac2VtcGVyaXMuY29tMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKC
# AgEAr6tl3SlmfsaiEOfMdtp4zvTErHoof7dk7J3pCnooplIEiChxu0y8qc9lcdPj
# 7pr8RJvSbG110CsfV6GzWevZUVJWmQqvE4mugzLxhFABL4t0r8HZSSa/gKMEndXr
# 3SUhwdbLmg38F+yuzyGoiHY55ecMHPWoz89tBYlezlISI2C0+E/RQC8/c8STflpX
# FCVEpqFwJnY1x5rz+jEDTu8ITyNmrhb66uzogNTdgsl0xasM9TpE5VKrWSLAg37i
# Frj0GRjwd/pzTfO3tXhH4zt728F04HuuPf+3F3ETLhSsrk1lBNwMV+UBVjPJrVro
# 1brvEHn7D88BicGkT/qFh0+R5jUu7O8BJ+/g4IHp4yKOtp/Ockp05Yi6H45fX35c
# QddB6twWIFbGcjRGAadYUSkacUOfGRzAJKQOJYmN3ISOJJT1hoHCFtR9sqjN0pQa
# 2k1bk/bJGmTrmt7uUPJ5Ucnl1qHgZkPD5R9ERXXjZ00cX5mOx5l0gpxvg+01R4cy
# TyxgRzAuBU46q6P8ESh4hiyJM+nnao8+eE8Sr/VN/VC7CCtLEGWl2/Ek1KeniiuZ
# SrdMFnnaI0G4tqqG97mSIBoPuKwBCk+FpvGXQ8u3jd2mU8P4uZo4hH8Mib4L81k/
# 8oSc+vmQzEBiBSY/S9g2j51EnoyzAuyvJMmcCVF1Rp9TUU0CAwEAAaOCAbEwggGt
# MA4GA1UdDwEB/wQEAwIHgDCBmwYIKwYBBQUHAQEEgY4wgYswSgYIKwYBBQUHMAKG
# Pmh0dHA6Ly9zZWN1cmUuZ2xvYmFsc2lnbi5jb20vY2FjZXJ0L2dzZ2NjcjQ1Y29k
# ZXNpZ25jYTIwMjAuY3J0MD0GCCsGAQUFBzABhjFodHRwOi8vb2NzcC5nbG9iYWxz
# aWduLmNvbS9nc2djY3I0NWNvZGVzaWduY2EyMDIwMFYGA1UdIARPME0wQQYJKwYB
# BAGgMgEyMDQwMgYIKwYBBQUHAgEWJmh0dHBzOi8vd3d3Lmdsb2JhbHNpZ24uY29t
# L3JlcG9zaXRvcnkvMAgGBmeBDAEEATAJBgNVHRMEAjAAMEUGA1UdHwQ+MDwwOqA4
# oDaGNGh0dHA6Ly9jcmwuZ2xvYmFsc2lnbi5jb20vZ3NnY2NyNDVjb2Rlc2lnbmNh
# MjAyMC5jcmwwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHwYDVR0jBBgwFoAU2rONwCSQ
# o2t30wygWd0hZ2R2C3gwHQYDVR0OBBYEFHl2JYTkRF1JSD0dmaZEJrMSJ1pZMA0G
# CSqGSIb3DQEBCwUAA4ICAQC1QWVq8P2sWcGYHIPqTtMGIv6YV8RNYVDsS2nkSUsU
# xGGZO0GrGKDNn0epo1M1dXWtbECkivTrVA2x3Ku/yVysHHSliLbcL/QCPkbXT8hr
# 3s71X53tbAQp96iMSt/+RURXWH7bnBOCLfO1BeH9ua0uRYBpy3OYfuDEICowr4SN
# Rf2iY0wSoWZ85QsBlMgLLFymJln9Pjw8SYsVOYkwfMiv1aT7uCxVlkYtKW9bkmyb
# HuKiEduQwSfs5GzegSFM+WcfC4JqBhVXRBxQljX53Y1rb3eA8CVLTHZPVqXXM8di
# 628y1IylTdTzXcriFjCmMYZ0re+FNlVBT6KhJ+nP+pcSmrbVy9qg/BX1fQD5XGT6
# 3VdQp4qfTK25uWHWHm0GlOMR/SyC5HEmpASUkL5tHr+n+9GoRyS8IjQop37RJ1hK
# oBXlH0ayyQWHvLQjCM5Hx+ARSDq3HdeqK3ToAuUDJ+G5qgr0BP3X9Ap4K7fSn8p0
# gafpMdSBWRnmfIhPa0E4XEMA++XQtfy+gA4nr/0zD05uB+vpSli97phr6f3duafm
# NJbH40z7xlg2euTBd7CkUtI3KwFq0pvdgln0Xsjl5NhR4yY7Y9oQIjWd9ooFYWqx
# nphR9JecB3P+CkVA3L7Xwqu5PIXSZ+bPhF5a8yNNThYmm8g20dl3vCaZiX5/RHvt
# 8jGCBjYwggYyAgEBMGkwWTELMAkGA1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNp
# Z24gbnYtc2ExLzAtBgNVBAMTJkdsb2JhbFNpZ24gR0NDIFI0NSBDb2RlU2lnbmlu
# ZyBDQSAyMDIwAgxJRexpZUAW6KGDPvwwDQYJYIZIAWUDBAIBBQCgfDAQBgorBgEE
# AYI3AgEMMQIwADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3
# AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg/oz6sRYs47p5ErRr
# koOdhAm4JXLLaRpxGNn3rP+ElsUwDQYJKoZIhvcNAQEBBQAEggIAY7SvyHZ2fcnC
# oz+Qu839/3Bhmsz652WcAP96eRQf4I218Fb59qIizEwrJHfUFmGmSk7IhVV36XaV
# Jh/5GzIKi35vPpgdKXPSfSBiLS09gFSy0nfuUiJ8T78yi3pSLYCkqqLORtk8dmCd
# /yzQoZ6+MgCEdPiKwBiF9qtln+pMaRQXTaugWxOaBMFUODUbNVY6EAlXJkAjMYkF
# MenMPfDb5MIuN1oEhoQa5oS+7XN7dMprVPh2B7YAOQ8EJGhJluyGVTlOTE50xPCf
# gst8WOHIMZC+3EdN4hk1gHzEL5Da87FzUcjW3DnOSioKHAV+MFqCyNEJs9Jt3OmF
# 1FCXjFriqltdPzITpjvBmbgFecaQ0+uCLw1AHG/OaXGhydwhqESR+KwX85KHYPfR
# GoOyeBgzyzH4UVfwubHlUUzD8rub2aZLF3WFPea4n6bgpBD1QWzUFjMX+iL2wOD2
# XG/8JZDYa8u5IkgPESwGG+j5AvTYJXKrP7jH0ieSktn+6cJ1Py4tWraOucFMNOLg
# NgNtzo5Z0fejvFRLhurCH61kq66Fe4FAgRNVSE5Hgy35jl3d75BIYpD93tAeyztF
# Tdt7MJXuNQGRtxjiHq74W4n4pLGdvMY/rFg9NPcZ4ElJXTED8JE/fXJ6MUMFaDys
# XM5OKnmcEgIKXaVKd9juG6TimNk3F8OhggMgMIIDHAYJKoZIhvcNAQkGMYIDDTCC
# AwkCAQEwdzBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4x
# OzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGlt
# ZVN0YW1waW5nIENBAhAMTWlyS5T6PCpKPSkHgD1aMA0GCWCGSAFlAwQCAQUAoGkw
# GAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNjI2
# MTUyNTMzWjAvBgkqhkiG9w0BCQQxIgQgkE8rwffHPgp6typXgRm66onqoAybQj7f
# ddbKpyDH+i4wDQYJKoZIhvcNAQEBBQAEggIARUdCXrMpazKXWGmGH5Ra88/F2UX2
# ZruQvgB9KijYy/vm4bMnb7uzDezWcliRsTDS7CN4VPWGKJrsyYgoLxp9xhYuy7wQ
# LT++/BEYu4PHJxFQWxFMoAQ5D2ewLuaPm8XI4bSOwe63jWPijZnrAfsv2xQbtVJU
# jjkltuuZCXa96Q9z3faFGBoge4j9yw6FS9aLwkF2JFklnaNLSMH7efD6A99Rn+p3
# Q/IdMV/q+buh/Rgg72yWU8Z+IWKAmPGXVOBLUL3ZgIK1SQgMkG+U0wUhrFMOWGgV
# nqscMCFiE386c9akCwsSJiVsUDta9LJU+Ni5o4q4m0DL6vNXbefQwm/ZgKk8tclM
# WWeWp3K0ijpXaMmQMxRgflqVnucfC9pCxbRNLTs93e0PUuZDK5Ehj2h6xrYVthEX
# i8Wm8mw5lRQU44UZ3UJRtK6SjgJLelZ+nma/FmPDywQi39WvyvUFHjAOpxZ2QP+Y
# go64SUqPEmzTazizL7l9b1iK5cTBJ+sSPrTMpktkiuYC9IX7vECp5ES0WvfNvC2Q
# 2ZZytnsa0mBzxTBaqRW8ZLAMHf2BHJZ28g3oLl0ZZ1HVs5vz/P5SMP9kVFCRlG2W
# gkEEzq57AJVV0thxfbkksCcAmPqA4w3QwNjd8vSqCWBUTsbaEqPZWcrx9Ayvut6c
# etbBUFxUmX0PQzY=
# SIG # End signature block
