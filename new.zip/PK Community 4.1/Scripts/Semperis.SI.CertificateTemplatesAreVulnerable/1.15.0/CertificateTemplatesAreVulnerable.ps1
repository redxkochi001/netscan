﻿[CmdletBinding()]
Param(
    [Parameter(Mandatory=$True,ParameterSetName='Execution')][String]$ForestName,
    [Parameter(Mandatory=$True,ParameterSetName='Execution')][String[]]$DomainNames,
    [Parameter(Mandatory=$False,ParameterSetName='Execution')]$StartAttackWindow,
    [Parameter(Mandatory=$False,ParameterSetName='Execution')]$EndAttackWindow,
    [Parameter(ParameterSetName='Metadata',Mandatory)][switch]$Metadata
)

$Global:self = @{
    ID = 156
    UUID = 'd64cab17-754c-4643-872b-a9113fbb7808'
    Version = '1.15.0'
    CategoryID = 3
    ShortName = 'SI000156'
    Name = 'Certificate templates with 3 or more insecure configurations'
    ScriptName = 'CertificateTemplatesAreVulnerable'
    Description = 'This indicator checks if certificate templates in the forest have a minimum of three insecure configurations - Manager approval is disabled, No authorized signatures are required, SAN enabled, Authentication EKU present.'
    Weight = 7
    Severity = 'Warning'
    Impact = 7
    LikelihoodOfCompromise = 'The following configurations of a certificate template can be exploited by adversaries:
        <br>        </br>
      1. Manager approval is disabled - new certificates are automatically approved if the user has the correct enrollment rights.
      <br>        </br>
      2. No authorized signatures are required - CSRs (Certificate Signing Requests) are not signed by any existing authorized certificate.
      <br>        </br>
      3. SAN (Subject Alternative Name) Enabled - Allowing the creator of a certificate template to specify the subjectAltName in the CSR, thus they can make the request as anyone, even a domain admin.
      <br>        </br>
      4. Authentication EKU (Enhanced Key Usage) present - if present, the EKU created from the certificate template will allow the user to authenticate with it.'
    ResultMessage = 'Found {0} certificate templates that can potentially be abused.'
    Remediation = 'Multiple actions can be taken to ensure certificate templates will be less vulnerable:
1. Enable manager approval - make sure manager approval is enabled and required on the certificate, and approve each request manually after inspecting it.
2. No authorized signatures are required - it is recommended to set it to 1 so that each request will have to be signed by an authorized certificate.
3. SAN Enabled - evaluate if the certificate needs to specify a subjectAltName, if not disable this option.
4. Authentication EKU present - make sure the certificate template is being used for authentication only.<br> For example, a certificate that is solely used for code signing should not also be used for authentication.<br>MITRE D3fend based on the reference: MITRE D3fend based on the reference: <a href="https://www.nccoe.nist.gov/sites/default/files/library/sp1800/tls-serv-cert-mgt-nist-sp1800-16b-final.pdf" target="_blank">NIST-SP1800-16B</a>'
    Types = @('IoE')
    DataSources = @('AD.LDAP')
    Targets = @('AD')
    Permissions = @()
    SecurityFrameworks = @(
        @{ Name = 'MITRE ATT&CK'; Tags = @('Credential Access', 'Privilege Escalation') },
        @{ Name = 'MITRE D3FEND'; Tags = @('Detect - Certificate Analysis') },
        @{ Name = 'ANSSI'; Tags = @('vuln1_adcs_template_auth_enroll_with_name') }
    )
    Products = @(
        @{ Name = 'DSP'; MinVersion = '3.5'; MaxVersion = '10'; Licenses = @('DSP-A', 'DSP-I') },
        @{ Name = 'PK'; MinVersion = '1.4'; MaxVersion = '10'; Licenses = @('Community', 'Post-Breach', 'BPIR') }
    )
    Selected = 1
}
if($Metadata){ return $self | ConvertTo-Json -Depth 8 -Compress }

Import-Module -Name Semperis-Lib

$outputObjects = [System.Collections.ArrayList]@()
$failedTemplatesCount = 0
# Client Authentication, PKINIT Client Authentication, Smart Card Logon, Any Purpose
$AuthEKU = @("1.3.6.1.5.5.7.3.2","1.3.6.1.5.2.3.4","1.3.6.1.4.1.311.20.2.2","2.5.29.37.0")

try{
    if ($PSBoundParameters['ForestName'] -and $PSBoundParameters['DomainNames']) {
        $ForestName = $ForestName.ToLower()
        $DomainNames = ConvertTo-Lowercase -DomainNames $DomainNames
    }
    $res = Initialize-res

    $forestDN = Get-DN $ForestName
    $results = @()
    $builtInTemplatesCNs = @("EnrollmentAgentOffline","WebServer","CA","SubCA","IPSECIntermediateOffline","OfflineRouter","CEPEncryption","ExchangeUser","ExchangeUserSignature","CrossCA",`
            "CAExchange","EnrollmentAgentOffline","WebServer","CA","SubCA","IPSECIntermediateOffline","OfflineRouter","CEPEncryption","ExchangeUser","ExchangeUserSignature",`
            "CrossCA","CAExchange","User","UserSignature","SmartcardUser","ClientAuth","SmartcardLogon","EFS","Administrator","EFSRecovery","CodeSigning","CTLSigning","EnrollmentAgent",`
            "MachineEnrollmentAgent","Machine","DomainController","IPSECIntermediateOnline","KeyRecoveryAgent","DomainControllerAuthentication","DirectoryEmailReplication","Workstation","RASAndIASServer","OCSPResponseSigning","KerberosAuthentication")

    $filter = ""

    foreach($cn in $builtInTemplatesCNs) {
        $filter += "(cn="+$cn+")"
    }

    $searchParams =
    @{
        dnsDomain = $forestName
        attributes = @("msPKI-Certificate-Name-Flag","msPKI-Enrollment-Flag","pKIExtendedKeyUsage","msPKI-RA-Signature","cn")
        baseDN = "CN=Certificate Templates,CN=Public Key Services,CN=Services,CN=Configuration,$forestDN"
        scope = "subtree"
        filter = "(&(objectClass=pKICertificateTemplate)(!(|$filter)))"
    }

    $results, $unavailableDomains = Search-ADConfig -forestName $ForestName -domainNames $DomainNames -searchADParameters $searchParams

    # remove any unavailable domains, checking their availability is slow and
    # Search-ADConfig will also check if not removed here
    $DomainNames = $DomainNames | Where-Object {$unavailableDomains -notcontains $_}

    if ($DomainNames.Count -gt 0) {
        $searchParams =
        @{
            attributes = "certificateTemplates"
            baseDN = "CN=Enrollment Services,CN=Public Key Services,CN=Services,CN=Configuration,$forestDN"
            scope = "subtree"
            filter = "(objectCategory=pKIEnrollmentService)"
        }
        $enterpriseCAs, $unavailable = Search-ADConfig -forestName $ForestName -domainNames $DomainNames -searchADParameters $searchParams
        $publishedCertificates = @()
        foreach ($enterpriseCA in $enterpriseCAs){
            foreach ($template in $enterpriseCA.Attributes.certificatetemplates){
                $publishedCertificates += [System.Text.Encoding]::ASCII.GetString($template)
            }
        }
    }

    $countPublishedCerts = 0

    if ($results)
    {
        foreach ($result in $results){
            $countAbusableProblems = 0
            $cn = $result.Attributes.cn[0]
            $sanEnabled = ([int] $result.Attributes.'mspki-certificate-name-flag'[$GET_DECIMAL_VALUE]) -band 1
            $managerApprovalNeeded = ([int] $result.Attributes.'mspki-enrollment-flag'[$GET_DECIMAL_VALUE]) -band 2
            $securitySignaturesNeeded = [int] $result.Attributes.'mspki-ra-signature'[$GET_DECIMAL_VALUE]
            $templateEKU = $result.Attributes.'pkiextendedkeyusage'
            $authEKUPresent = $false
            $isPublished = $false

            foreach ($eku in $templateEKU){
                $eku = [System.Text.Encoding]::ASCII.GetString($eku)
                if ($AuthEKU.Contains($eku)){
                    $authEKUPresent = $true
                    $countTemplateProblems++
                    break
                }
            }

            $abusableProblems = ""
            if ($sanEnabled){
                $countAbusableProblems ++;
                $abusableProblems += "SAN Enabled, "
            }
            if ($managerApprovalNeeded -eq 0){
                $countAbusableProblems ++;
                $abusableProblems += "no Manager Approval needed, "
            }
            if ($securitySignaturesNeeded -eq 0){
                $countAbusableProblems ++;
                $abusableProblems += "No Signatures needed, "
            }
            if ($authEKUPresent){
                $countAbusableProblems ++;
                $abusableProblems += "Authentication EKU present"
            }

            if ($countAbusableProblems -ge 3)
            {
                if ($cn -in $publishedCertificates)
                {
                    $isPublished = $true
                    $countPublishedCerts++
                }
                $failedTemplatesCount++
                $thisOutput = [pscustomobject][ordered] @{
                    DistinguishedName=$result.DistinguishedName
                    CertificateTemplateName = $result.Attributes.cn[$GET_STRING]
                    PotentialAbusableProblems = $abusableProblems
                    Published = $isPublished
                }
                [void]$outputObjects.Add($thisOutput)
            }
        }
    }
    If ($outputObjects){
        $configArgs = @{
            ScriptName = $self.ScriptName
            Path = $MyInvocation.MyCommand.ScriptBlock.File
            Fields = $outputObjects[0]
        }
        $config = Resolve-Configuration @configArgs
        $outputObjects | Set-IgnoredFlag -Configuration $config
        $scoreOutput = $outputObjects | Get-Score -Impact $self.Impact
        if($scoreOutput.Score -lt 100)
        {
            $res.ResultObjects = $outputObjects
            $res.ResultMessage = $self.ResultMessage -f $outputObjects.Count
            $res.Remediation = $self.Remediation
            $res.Status = [Semperis.PSSecurityIndicatorResult.ScriptStatus]"Failed"
            $res.Score = $scoreOutput.Score
        }
        if ($scoreOutput.Ignoredcount -gt 0)
        {
            $res.ResultMessage += " ($($scoreOutput.Ignoredcount) Objects ignored)."
        }
    }
    elseif ($DomainNames.Count -eq 0) {
        $res.Status = [Semperis.PSSecurityIndicatorResult.ScriptStatus]"Error"
        $res.ResultMessage = "Unable to retrieve the Configuration partition. The following domains were unavailable: $($unavailableDomains -join ', ')"
        $res.Remediation = "None"
    }
}
catch {
    return ConvertTo-ErrorResult $_
}
return $res

# SIG # Begin signature block
# MIItmQYJKoZIhvcNAQcCoIItijCCLYYCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDVWEXMN++xfDZN
# O6BQYk4+zTcwCiBT4tuSYol7SCgtHqCCJrkwggWNMIIEdaADAgECAhAOmxiO+dAt
# 5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBa
# Fw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3E
# MB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKy
# unWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsF
# xl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU1
# 5zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJB
# MtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObUR
# WBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6
# nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxB
# YKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5S
# UUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+x
# q4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIB
# NjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMC
# AYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0Nc
# Vec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnov
# Lbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65Zy
# oUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFW
# juyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPF
# mCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9z
# twGpn1eqXijiuZQwggWiMIIEiqADAgECAhB4AxhCRXCKQc9vAbjutKlUMA0GCSqG
# SIb3DQEBDAUAMEwxIDAeBgNVBAsTF0dsb2JhbFNpZ24gUm9vdCBDQSAtIFIzMRMw
# EQYDVQQKEwpHbG9iYWxTaWduMRMwEQYDVQQDEwpHbG9iYWxTaWduMB4XDTIwMDcy
# ODAwMDAwMFoXDTI5MDMxODAwMDAwMFowUzELMAkGA1UEBhMCQkUxGTAXBgNVBAoT
# EEdsb2JhbFNpZ24gbnYtc2ExKTAnBgNVBAMTIEdsb2JhbFNpZ24gQ29kZSBTaWdu
# aW5nIFJvb3QgUjQ1MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAti3F
# MN166KuQPQNysDpLmRZhsuX/pWcdNxzlfuyTg6qE9aNDm5hFirhjV12bAIgEJen4
# aJJLgthLyUoD86h/ao+KYSe9oUTQ/fU/IsKjT5GNswWyKIKRXftZiAULlwbCmPgs
# pzMk7lA6QczwoLB7HU3SqFg4lunf+RuRu4sQLNLHQx2iCXShgK975jMKDFlrjrz0
# q1qXe3+uVfuE8ID+hEzX4rq9xHWhb71hEHREspgH4nSr/2jcbCY+6R/l4ASHrTDT
# DI0DfFW4FnBcJHggJetnZ4iruk40mGtwEd44ytS+ocCc4d8eAgHYO+FnQ4S2z/x0
# ty+Eo7+6CTc9Z2yxRVwZYatBg/WsHet3DUZHc86/vZWV7Z0riBD++ljop1fhs8+o
# WukHJZsSxJ6Acj2T3IyU3ztE5iaA/NLDA/CMDNJF1i7nj5ie5gTuQm5nfkIWcWLn
# BPlgxmShtpyBIU4rxm1olIbGmXRzZzF6kfLUjHlufKa7fkZvTcWFEivPmiJECKiF
# N84HYVcGFxIkwMQxc6GYNVdHfhA6RdktpFGQmKmgBzfEZRqqHGsWd/enl+w/GTCZ
# bzH76kCy59LE+snQ8FB2dFn6jW0XMr746X4D9OeHdZrUSpEshQMTAitCgPKJajbP
# yEygzp74y42tFqfT3tWbGKfGkjrxgmPxLg4kZN8CAwEAAaOCAXcwggFzMA4GA1Ud
# DwEB/wQEAwIBhjATBgNVHSUEDDAKBggrBgEFBQcDAzAPBgNVHRMBAf8EBTADAQH/
# MB0GA1UdDgQWBBQfAL9GgAr8eDm3pbRD2VZQu86WOzAfBgNVHSMEGDAWgBSP8Et/
# qC5FJK5NUPpjmove4t0bvDB6BggrBgEFBQcBAQRuMGwwLQYIKwYBBQUHMAGGIWh0
# dHA6Ly9vY3NwLmdsb2JhbHNpZ24uY29tL3Jvb3RyMzA7BggrBgEFBQcwAoYvaHR0
# cDovL3NlY3VyZS5nbG9iYWxzaWduLmNvbS9jYWNlcnQvcm9vdC1yMy5jcnQwNgYD
# VR0fBC8wLTAroCmgJ4YlaHR0cDovL2NybC5nbG9iYWxzaWduLmNvbS9yb290LXIz
# LmNybDBHBgNVHSAEQDA+MDwGBFUdIAAwNDAyBggrBgEFBQcCARYmaHR0cHM6Ly93
# d3cuZ2xvYmFsc2lnbi5jb20vcmVwb3NpdG9yeS8wDQYJKoZIhvcNAQEMBQADggEB
# AKz3zBWLMHmoHQsoiBkJ1xx//oa9e1ozbg1nDnti2eEYXLC9E10dI645UHY3qkT9
# XwEjWYZWTMytvGQTFDCkIKjgP+icctx+89gMI7qoLao89uyfhzEHZfU5p1GCdeHy
# L5f20eFlloNk/qEdUfu1JJv10ndpvIUsXPpYd9Gup7EL4tZ3u6m0NEqpbz308w2V
# Xeb5ekWwJRcxLtv3D2jmgx+p9+XUnZiM02FLL8Mofnrekw60faAKbZLEtGY/fadY
# 7qz37MMIAas4/AocqcWXsojICQIZ9lyaGvFNbDDUswarAGBIDXirzxetkpNiIHd1
# bL3IMrTcTevZ38GQlim9wX8wggauMIIElqADAgECAhAHNje3JFR82Ees/ShmKl5b
# MA0GCSqGSIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMjAzMjMwMDAwMDBaFw0zNzAzMjIyMzU5
# NTlaMGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkG
# A1UEAxMyRGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3Rh
# bXBpbmcgQ0EwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDGhjUGSbPB
# PXJJUVXHJQPE8pE3qZdRodbSg9GeTKJtoLDMg/la9hGhRBVCX6SI82j6ffOciQt/
# nR+eDzMfUBMLJnOWbfhXqAJ9/UO0hNoR8XOxs+4rgISKIhjf69o9xBd/qxkrPkLc
# Z47qUT3w1lbU5ygt69OxtXXnHwZljZQp09nsad/ZkIdGAHvbREGJ3HxqV3rwN3mf
# XazL6IRktFLydkf3YYMZ3V+0VAshaG43IbtArF+y3kp9zvU5EmfvDqVjbOSmxR3N
# Ng1c1eYbqMFkdECnwHLFuk4fsbVYTXn+149zk6wsOeKlSNbwsDETqVcplicu9Yem
# j052FVUmcJgmf6AaRyBD40NjgHt1biclkJg6OBGz9vae5jtb7IHeIhTZgirHkr+g
# 3uM+onP65x9abJTyUpURK1h0QCirc0PO30qhHGs4xSnzyqqWc0Jon7ZGs506o9UD
# 4L/wojzKQtwYSH8UNM/STKvvmz3+DrhkKvp1KCRB7UK/BZxmSVJQ9FHzNklNiyDS
# LFc1eSuo80VgvCONWPfcYd6T/jnA+bIwpUzX6ZhKWD7TA4j+s4/TXkt2ElGTyYwM
# O1uKIqjBJgj5FBASA31fI7tk42PgpuE+9sJ0sj8eCXbsq11GdeJgo1gJASgADoRU
# 7s7pXcheMBK9Rp6103a50g5rmQzSM7TNsQIDAQABo4IBXTCCAVkwEgYDVR0TAQH/
# BAgwBgEB/wIBADAdBgNVHQ4EFgQUuhbZbU2FL3MpdpovdYxqII+eyG8wHwYDVR0j
# BBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0
# cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0
# cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8E
# PDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkUm9vdEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEw
# DQYJKoZIhvcNAQELBQADggIBAH1ZjsCTtm+YqUQiAX5m1tghQuGwGC4QTRPPMFPO
# vxj7x1Bd4ksp+3CKDaopafxpwc8dB+k+YMjYC+VcW9dth/qEICU0MWfNthKWb8RQ
# TGIdDAiCqBa9qVbPFXONASIlzpVpP0d3+3J0FNf/q0+KLHqrhc1DX+1gtqpPkWae
# LJ7giqzl/Yy8ZCaHbJK9nXzQcAp876i8dU+6WvepELJd6f8oVInw1YpxdmXazPBy
# oyP6wCeCRK6ZJxurJB4mwbfeKuv2nrF5mYGjVoarCkXJ38SNoOeY+/umnXKvxMfB
# wWpx2cYTgAnEtp/Nh4cku0+jSbl3ZpHxcpzpSwJSpzd+k1OsOx0ISQ+UzTl63f8l
# Y5knLD0/a6fxZsNBzU+2QJshIUDQtxMkzdwdeDrknq3lNHGS1yZr5Dhzq6YBT70/
# O3itTK37xJV77QpfMzmHQXh6OOmc4d0j/R0o08f56PGYX/sr2H7yRp11LB4nLCbb
# bxV7HhmLNriT1ObyF5lZynDwN7+YAN8gFk8n+2BnFqFmut1VwDophrCYoCvtlUG3
# OtUVmDG0YgkPCr2B2RP+v6TR81fZvAT6gt4y3wSJ8ADNXcL50CN/AAvkdgIm2fBl
# dkKmKYcJRyvmfxqkhQ/8mJb2VVQrH4D6wPIOK+XW+6kvRBVK5xMOHds3OBqhK/bt
# 1nz8MIIGwjCCBKqgAwIBAgIQBUSv85SdCDmmv9s/X+VhFjANBgkqhkiG9w0BAQsF
# ADBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNV
# BAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1w
# aW5nIENBMB4XDTIzMDcxNDAwMDAwMFoXDTM0MTAxMzIzNTk1OVowSDELMAkGA1UE
# BhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMSAwHgYDVQQDExdEaWdpQ2Vy
# dCBUaW1lc3RhbXAgMjAyMzCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AKNTRYcdg45brD5UsyPgz5/X5dLnXaEOCdwvSKOXejsqnGfcYhVYwamTEafNqrJq
# 3RApih5iY2nTWJw1cb86l+uUUI8cIOrHmjsvlmbjaedp/lvD1isgHMGXlLSlUIHy
# z8sHpjBoyoNC2vx/CSSUpIIa2mq62DvKXd4ZGIX7ReoNYWyd/nFexAaaPPDFLnkP
# G2ZS48jWPl/aQ9OE9dDH9kgtXkV1lnX+3RChG4PBuOZSlbVH13gpOWvgeFmX40Qr
# StWVzu8IF+qCZE3/I+PKhu60pCFkcOvV5aDaY7Mu6QXuqvYk9R28mxyyt1/f8O52
# fTGZZUdVnUokL6wrl76f5P17cz4y7lI0+9S769SgLDSb495uZBkHNwGRDxy1Uc2q
# TGaDiGhiu7xBG3gZbeTZD+BYQfvYsSzhUa+0rRUGFOpiCBPTaR58ZE2dD9/O0V6M
# qqtQFcmzyrzXxDtoRKOlO0L9c33u3Qr/eTQQfqZcClhMAD6FaXXHg2TWdc2PEnZW
# pST618RrIbroHzSYLzrqawGw9/sqhux7UjipmAmhcbJsca8+uG+W1eEQE/5hRwqM
# /vC2x9XH3mwk8L9CgsqgcT2ckpMEtGlwJw1Pt7U20clfCKRwo+wK8REuZODLIivK
# 8SgTIUlRfgZm0zu++uuRONhRB8qUt+JQofM604qDy0B7AgMBAAGjggGLMIIBhzAO
# BgNVHQ8BAf8EBAMCB4AwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEF
# BQcDCDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwHwYDVR0jBBgw
# FoAUuhbZbU2FL3MpdpovdYxqII+eyG8wHQYDVR0OBBYEFKW27xPn783QZKHVVqll
# MaPe1eNJMFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydFRydXN0ZWRHNFJTQTQwOTZTSEEyNTZUaW1lU3RhbXBpbmdDQS5j
# cmwwgZAGCCsGAQUFBwEBBIGDMIGAMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5k
# aWdpY2VydC5jb20wWAYIKwYBBQUHMAKGTGh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0
# LmNvbS9EaWdpQ2VydFRydXN0ZWRHNFJTQTQwOTZTSEEyNTZUaW1lU3RhbXBpbmdD
# QS5jcnQwDQYJKoZIhvcNAQELBQADggIBAIEa1t6gqbWYF7xwjU+KPGic2CX/yyzk
# zepdIpLsjCICqbjPgKjZ5+PF7SaCinEvGN1Ott5s1+FgnCvt7T1IjrhrunxdvcJh
# N2hJd6PrkKoS1yeF844ektrCQDifXcigLiV4JZ0qBXqEKZi2V3mP2yZWK7Dzp703
# DNiYdk9WuVLCtp04qYHnbUFcjGnRuSvExnvPnPp44pMadqJpddNQ5EQSviANnqlE
# 0PjlSXcIWiHFtM+YlRpUurm8wWkZus8W8oM3NG6wQSbd3lqXTzON1I13fXVFoaVY
# JmoDRd7ZULVQjK9WvUzF4UbFKNOt50MAcN7MmJ4ZiQPq1JE3701S88lgIcRWR+3a
# EUuMMsOI5ljitts++V+wQtaP4xeR0arAVeOGv6wnLEHQmjNKqDbUuXKWfpd5OEhf
# ysLcPTLfddY2Z1qJ+Panx+VPNTwAvb6cKmx5AdzaROY63jg7B145WPR8czFVoIAR
# yxQMfq68/qTreWWqaNYiyjvrmoI1VygWy2nyMpqy0tg6uLFGhmu6F/3Ed2wVbK6r
# r3M66ElGt9V/zLY4wNjsHPW2obhDLN9OTH0eaHDAdwrUAuBcYLso/zjlUlrWrBci
# I0707NMX+1Br/wd3H3GXREHJuEbTbDJ8WC9nR2XlG3O2mflrLAZG70Ee8PBf4NvZ
# rZCARK+AEEGKMIIG5jCCBM6gAwIBAgIQd70OA6G3CPhUqwZyENkERzANBgkqhkiG
# 9w0BAQsFADBTMQswCQYDVQQGEwJCRTEZMBcGA1UEChMQR2xvYmFsU2lnbiBudi1z
# YTEpMCcGA1UEAxMgR2xvYmFsU2lnbiBDb2RlIFNpZ25pbmcgUm9vdCBSNDUwHhcN
# MjAwNzI4MDAwMDAwWhcNMzAwNzI4MDAwMDAwWjBZMQswCQYDVQQGEwJCRTEZMBcG
# A1UEChMQR2xvYmFsU2lnbiBudi1zYTEvMC0GA1UEAxMmR2xvYmFsU2lnbiBHQ0Mg
# UjQ1IENvZGVTaWduaW5nIENBIDIwMjAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDWQk3540/GI/RsHYGmMPdIPc/Q5Y3lICKWB0Q1XQbPDx1wYOYmVPpT
# I2ACqF8CAveOyW49qXgFvY71TxkkmXzPERabH3tr0qN7aGV3q9ixLD/TcgYyXFus
# UGcsJU1WBjb8wWJMfX2GFpWaXVS6UNCwf6JEGenWbmw+E8KfEdRfNFtRaDFjCvhb
# 0N66WV8xr4loOEA+COhTZ05jtiGO792NhUFVnhy8N9yVoMRxpx8bpUluCiBZfomj
# WBWXACVp397CalBlTlP7a6GfGB6KDl9UXr3gW8/yDATS3gihECb3svN6LsKOlsE/
# zqXa9FkojDdloTGWC46kdncVSYRmgiXnQwp3UrGZUUL/obLdnNLcGNnBhqlAHUGX
# Yoa8qP+ix2MXBv1mejaUASCJeB+Q9HupUk5qT1QGKoCvnsdQQvplCuMB9LFurA6o
# 44EZqDjIngMohqR0p0eVfnJaKnsVahzEaeawvkAZmcvSfVVOIpwQ4KFbw7MueovE
# 3vFLH4woeTBFf2wTtj0s/y1KiirsKA8tytScmIpKbVo2LC/fusviQUoIdxiIrTVh
# lBLzpHLr7jaep1EnkTz3ohrM/Ifll+FRh2npIsyDwLcPRWwH4UNP1IxKzs9jsbWk
# EHr5DQwosGs0/iFoJ2/s+PomhFt1Qs2JJnlZnWurY3FikCUNCCDx/wIDAQABo4IB
# rjCCAaowDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMBIGA1Ud
# EwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYEFNqzjcAkkKNrd9MMoFndIWdkdgt4MB8G
# A1UdIwQYMBaAFB8Av0aACvx4ObeltEPZVlC7zpY7MIGTBggrBgEFBQcBAQSBhjCB
# gzA5BggrBgEFBQcwAYYtaHR0cDovL29jc3AuZ2xvYmFsc2lnbi5jb20vY29kZXNp
# Z25pbmdyb290cjQ1MEYGCCsGAQUFBzAChjpodHRwOi8vc2VjdXJlLmdsb2JhbHNp
# Z24uY29tL2NhY2VydC9jb2Rlc2lnbmluZ3Jvb3RyNDUuY3J0MEEGA1UdHwQ6MDgw
# NqA0oDKGMGh0dHA6Ly9jcmwuZ2xvYmFsc2lnbi5jb20vY29kZXNpZ25pbmdyb290
# cjQ1LmNybDBWBgNVHSAETzBNMEEGCSsGAQQBoDIBMjA0MDIGCCsGAQUFBwIBFiZo
# dHRwczovL3d3dy5nbG9iYWxzaWduLmNvbS9yZXBvc2l0b3J5LzAIBgZngQwBBAEw
# DQYJKoZIhvcNAQELBQADggIBAAiIcibGr/qsXwbAqoyQ2tCywKKX/24TMhZU/T70
# MBGfj5j5m1Ld8qIW7tl4laaafGG4BLX468v0YREz9mUltxFCi9hpbsf/lbSBQ6l+
# rr+C1k3MEaODcWoQXhkFp+dsf1b0qFzDTgmtWWu4+X6lLrj83g7CoPuwBNQTG8cn
# qbmqLTE7z0ZMnetM7LwunPGHo384aV9BQGf2U33qQe+OPfup1BE4Rt886/bNIr0T
# zfDh5uUzoL485HjVG8wg8jBzsCIc9oTWm1wAAuEoUkv/EktA6u6wGgYGnoTm5/Db
# hEb7c9krQrbJVzTHFsCm6yG5qg73/tvK67wXy7hn6+M+T9uplIZkVckJCsDZBHFK
# EUtaZMO8eHitTEcmZQeZ1c02YKEzU7P2eyrViUA8caWr+JlZ/eObkkvdBb0LDHgG
# K89T2L0SmlsnhoU/kb7geIBzVN+nHWcrarauTYmAJAhScFDzAf9Eri+a4OFJCOHh
# W9c40Z4Kip2UJ5vKo7nb4jZq42+5WGLgNng2AfrBp4l6JlOjXLvSsuuKy2MIL/4e
# 81Yp4jWb2P/ppb1tS1ksiSwvUru1KZDaQ0e8ct282b+Awdywq7RLHVg2N2Trm+GF
# F5opov3mCNKS/6D4fOHpp9Ewjl8mUCvHouKXd4rv2E0+JuuZQGDzPGcMtghyKTVT
# gTTcMIIHHDCCBQSgAwIBAgIMSUXsaWVAFuihgz78MA0GCSqGSIb3DQEBCwUAMFkx
# CzAJBgNVBAYTAkJFMRkwFwYDVQQKExBHbG9iYWxTaWduIG52LXNhMS8wLQYDVQQD
# EyZHbG9iYWxTaWduIEdDQyBSNDUgQ29kZVNpZ25pbmcgQ0EgMjAyMDAeFw0yMjAz
# MDIxMTQ4MzlaFw0yNDA2MTQxNDMwNDRaMIGJMQswCQYDVQQGEwJVUzERMA8GA1UE
# CBMITmV3IFlvcmsxETAPBgNVBAcTCE5ldyBZb3JrMRYwFAYDVQQKEw1TRU1QRVJJ
# UyBJTkMuMRYwFAYDVQQDEw1TRU1QRVJJUyBJTkMuMSQwIgYJKoZIhvcNAQkBFhVj
# b2Rlc2lnbkBzZW1wZXJpcy5jb20wggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIK
# AoICAQCvq2XdKWZ+xqIQ58x22njO9MSseih/t2TsnekKeiimUgSIKHG7TLypz2Vx
# 0+PumvxEm9JsbXXQKx9XobNZ69lRUlaZCq8Tia6DMvGEUAEvi3SvwdlJJr+AowSd
# 1evdJSHB1suaDfwX7K7PIaiIdjnl5wwc9ajPz20FiV7OUhIjYLT4T9FALz9zxJN+
# WlcUJUSmoXAmdjXHmvP6MQNO7whPI2auFvrq7OiA1N2CyXTFqwz1OkTlUqtZIsCD
# fuIWuPQZGPB3+nNN87e1eEfjO3vbwXTge649/7cXcRMuFKyuTWUE3AxX5QFWM8mt
# WujVuu8QefsPzwGJwaRP+oWHT5HmNS7s7wEn7+DggenjIo62n85ySnTliLofjl9f
# flxB10Hq3BYgVsZyNEYBp1hRKRpxQ58ZHMAkpA4liY3chI4klPWGgcIW1H2yqM3S
# lBraTVuT9skaZOua3u5Q8nlRyeXWoeBmQ8PlH0RFdeNnTRxfmY7HmXSCnG+D7TVH
# hzJPLGBHMC4FTjqro/wRKHiGLIkz6edqjz54TxKv9U39ULsIK0sQZaXb8STUp6eK
# K5lKt0wWedojQbi2qob3uZIgGg+4rAEKT4Wm8ZdDy7eN3aZTw/i5mjiEfwyJvgvz
# WT/yhJz6+ZDMQGIFJj9L2DaPnUSejLMC7K8kyZwJUXVGn1NRTQIDAQABo4IBsTCC
# Aa0wDgYDVR0PAQH/BAQDAgeAMIGbBggrBgEFBQcBAQSBjjCBizBKBggrBgEFBQcw
# AoY+aHR0cDovL3NlY3VyZS5nbG9iYWxzaWduLmNvbS9jYWNlcnQvZ3NnY2NyNDVj
# b2Rlc2lnbmNhMjAyMC5jcnQwPQYIKwYBBQUHMAGGMWh0dHA6Ly9vY3NwLmdsb2Jh
# bHNpZ24uY29tL2dzZ2NjcjQ1Y29kZXNpZ25jYTIwMjAwVgYDVR0gBE8wTTBBBgkr
# BgEEAaAyATIwNDAyBggrBgEFBQcCARYmaHR0cHM6Ly93d3cuZ2xvYmFsc2lnbi5j
# b20vcmVwb3NpdG9yeS8wCAYGZ4EMAQQBMAkGA1UdEwQCMAAwRQYDVR0fBD4wPDA6
# oDigNoY0aHR0cDovL2NybC5nbG9iYWxzaWduLmNvbS9nc2djY3I0NWNvZGVzaWdu
# Y2EyMDIwLmNybDATBgNVHSUEDDAKBggrBgEFBQcDAzAfBgNVHSMEGDAWgBTas43A
# JJCja3fTDKBZ3SFnZHYLeDAdBgNVHQ4EFgQUeXYlhOREXUlIPR2ZpkQmsxInWlkw
# DQYJKoZIhvcNAQELBQADggIBALVBZWrw/axZwZgcg+pO0wYi/phXxE1hUOxLaeRJ
# SxTEYZk7QasYoM2fR6mjUzV1da1sQKSK9OtUDbHcq7/JXKwcdKWIttwv9AI+RtdP
# yGvezvVfne1sBCn3qIxK3/5FRFdYftucE4It87UF4f25rS5FgGnLc5h+4MQgKjCv
# hI1F/aJjTBKhZnzlCwGUyAssXKYmWf0+PDxJixU5iTB8yK/VpPu4LFWWRi0pb1uS
# bJse4qIR25DBJ+zkbN6BIUz5Zx8LgmoGFVdEHFCWNfndjWtvd4DwJUtMdk9Wpdcz
# x2LrbzLUjKVN1PNdyuIWMKYxhnSt74U2VUFPoqEn6c/6lxKattXL2qD8FfV9APlc
# ZPrdV1Cnip9Mrbm5YdYebQaU4xH9LILkcSakBJSQvm0ev6f70ahHJLwiNCinftEn
# WEqgFeUfRrLJBYe8tCMIzkfH4BFIOrcd16ordOgC5QMn4bmqCvQE/df0Cngrt9Kf
# ynSBp+kx1IFZGeZ8iE9rQThcQwD75dC1/L6ADiev/TMPTm4H6+lKWL3umGvp/d25
# p+Y0lsfjTPvGWDZ65MF3sKRS0jcrAWrSm92CWfReyOXk2FHjJjtj2hAiNZ32igVh
# arGemFH0l5wHc/4KRUDcvtfCq7k8hdJn5s+EXlrzI01OFiabyDbR2Xe8JpmJfn9E
# e+3yMYIGNjCCBjICAQEwaTBZMQswCQYDVQQGEwJCRTEZMBcGA1UEChMQR2xvYmFs
# U2lnbiBudi1zYTEvMC0GA1UEAxMmR2xvYmFsU2lnbiBHQ0MgUjQ1IENvZGVTaWdu
# aW5nIENBIDIwMjACDElF7GllQBbooYM+/DANBglghkgBZQMEAgEFAKB8MBAGCisG
# AQQBgjcCAQwxAjAAMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQB
# gjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCARtWAfEQh4cr1k
# BFafb6KBz9cb1Xajw+SSGfeCH0XSJzANBgkqhkiG9w0BAQEFAASCAgBgBiXJgF7V
# /gdxLChcAlIZ10DF0NqnQL9TqFN4yPvGGpUhiMxeiESQShfe9s0sv1MYiIvujhOo
# u+u4fuGrCYchVn73JgYXxYgC10NVYRjdW0uPEU1ySZ0Tf+QKz3kCkX6Finnf7ouF
# EJQ3yE4wXKURwBK3aE/cxktDI3kRIV9/t4q5RWKDY1sP0A7QhjN2OM5Eqoc19cGk
# LVwV7gys1G5pdg0mBvve9ucZMtgfn3patRzIEXOylllrsFN/yVLhFVL+yZ7g4qnC
# pDNJabyACJGVNi1jS58P7PqaU6h/usbftQiL+wZ1qoB1HuN5ctCMEmoXD79kJepx
# P/FA6/odSJRAaPzR3mOuNh07h+xx8s7qN7dE1xWVL37hLx5WNeuXX311eC/rLXOp
# AqXYEwjqBa1DVUTSOVgD3pMGH0cmq/8bn21Z6h0YPOGBNPokg6naWfK/uzTrhTEJ
# Cn+CwgoZCA2AkvkzZHrSdkmWx1dREBl6hnz9Q1myYnqAxLks+dldOmkiRlCg4b0a
# 0Q5lVdcSxpCRddMx3GQesStg27W0dP2h9EFH6EWCyVBE9JGR7nX03DEQUhayEms+
# upxfpGOhYjyjDsct80QbXw1Wv0I5dCCIYCeYrW18gJsUsP1INjDCiytRvlqNeCQN
# CNHM7NKyX89LLRJwuyLPwmVmGHJNbbqBh6GCAyAwggMcBgkqhkiG9w0BCQYxggMN
# MIIDCQIBATB3MGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5j
# LjE7MDkGA1UEAxMyRGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBU
# aW1lU3RhbXBpbmcgQ0ECEAVEr/OUnQg5pr/bP1/lYRYwDQYJYIZIAWUDBAIBBQCg
# aTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0yMzA4
# MjgxMjUyNThaMC8GCSqGSIb3DQEJBDEiBCAOoj83N4mmMxgtpDC4tposXHu7lWAm
# HmamxT5HTsxSGzANBgkqhkiG9w0BAQEFAASCAgAe3opmsJfPMZrCKEQBju0xGCJO
# mnfyTbA7wwRET9LDEAkKtFXZtQ0Jtv6iqhg4ju6vhnKfBLIRw77k73GYZxifasCw
# hJuoIcAxy459y/U6e1IVs1AOCRi2uKmHcFh7r2Cqe629ykbacX9xqvoyjVRsc/Hm
# ZJmrS9gqkwW8JhvOA4d2x0qAjbkmeRYGYN4hckCMZod6v/JHkH/E3zaCX7g6b7kB
# ygHyg9KoJ6g6hpPYICjSkt1n9cybCu/31a68m+i0M9bjxNb3HACoxT0fElKkRs43
# ayjtXCGBD4nMF0xiOTpeoNRNeTDgnu/3ZM8sxq9LiSMKTszWzERAqbFRz7nf7DIc
# FNtCFZ65W9UZCNTV1r0KH0aAQbCYqfl8aALuFM7YfMHB8cG1agPV6+m5jAyVGqbd
# D1NNfZZbX1XMU7qub9FbnFdl/phy8pviuPbe+PHqKk45+yBDCovk8giMYuuvknBs
# r5TjFuB4MF6LKYWn0ftXloqnNdD+4fFENE/z4ql93Y4ho6MRBF2gPYTzfCFhzOoS
# KjY59QKD3o/u8DF8TOD0NVcENY+Fd6JI661p21vAOcVjU3oJsFKuHqkBxgWsn65i
# onMO0PDr7RAEvd4eA6iZdonEKxvTgjCRB2Xejtln5A45Z5wwBC7IkGj6+V5JY7HV
# nvPUBQgA1LvMoyjDDw==
# SIG # End signature block
