﻿[CmdletBinding()]
Param(
    [Parameter(ParameterSetName='Execution')]$ForestName,
    [Parameter(ParameterSetName='Execution')]$DomainNames,
    [Parameter(ParameterSetName='Execution')][String]$TenantId,
    [Parameter(ParameterSetName='Execution')][String]$TenantAppId,
    [Parameter(ParameterSetName='Execution')][String]$TenantAppSecret,
    [Parameter(Mandatory=$False,ParameterSetName='Execution')]$StartAttackWindow,
    [Parameter(Mandatory=$False,ParameterSetName='Execution')]$EndAttackWindow,
    [Parameter(ParameterSetName='Metadata',Mandatory)][switch]$Metadata
)

$Global:self = @{
    ID = 207
    UUID = '1a1a74a5-c9a3-44ad-b4c2-9de7c8a10043'
    Version = '1.0.97827'
    CategoryID = 6
    ShortName = 'SI000207'
    Name = 'Non-admin users can create tenants'
    ScriptName = 'AAD_UsersCanCreateTenants'
    Description = 'This indicator checks for an authorization policy that enables non-admin users to create Azure AD tenants. Required permissions: Policy.Read.All'
    Weight = 7
    Severity = 'Warning'
    
    LikelihoodOfCompromise = 'Badly configured Azure AD tenants that are linked to users from the parent (organization) tenant, may be compromised more easily and won''t be well monitored and secured.'
    ResultMessage = 'Non-admin users are able to create Azure AD tenants'
    Remediation = 'To ensure better security practices, it is highly recommended to disable the setting that allows non-admin users to create Azure AD tenants.
        Follow these steps to restrict non-admin users from creating tenants:<br><br>
        Navigate to the Azure Active Directory <a href="https://portal.azure.com" target="_blank">portal.</a><br>
        Navigate to the "User settings" section.<br>
        Find the "Tenant creation" option.<br>
        Select "Yes" from the available options to disable users'' ability to create Azure AD tenants.<br>
        By following these steps, you restrict the creation of Azure AD tenants to the global administrator or tenant creator roles.<br>
        This helps to ensure tighter control over tenant creation and reduces the risk of unauthorized access or potential security vulnerabilities.'
    Types = @('IoE')
    DataSources = @('AAD.GraphAPI')
    Targets = @('AAD')
    Permissions = @('AAD.GraphAPI/Policy.Read.All')
    SecurityFrameworks = @(
        @{ Name = 'MITRE ATT&CK'; Tags = @('Initial Access', 'Persistence', 'Privilege Escalation') },
        @{ Name = 'MITRE D3FEND'; Tags = @('Model - Access Modeling') }
    )
    Products = @(
        @{ Name = 'DSP'; MinVersion = '3.6'; MaxVersion = '10'; Licenses = @('DSP-I-AAD') },
        @{ Name = 'PK'; MinVersion = '1.5'; MaxVersion = '10'; Licenses = @('Community', 'Post-Breach', 'BPIR') }
    )
    Selected = 1
}
if($Metadata){ return $self | ConvertTo-Json -Depth 8 -Compress }

Import-Module -Name Semperis-Lib

try {
    if ($PSBoundParameters['ForestName'] -and $PSBoundParameters['DomainNames']) {
        $ForestName = $ForestName.ToLower()
        $DomainNames = ConvertTo-Lowercase -DomainNames $DomainNames
    }
    $res = New-Object Semperis.PSSecurityIndicatorResult.SecurityIndicatorResult

    If (-not $TenantAppSecret) {
        $res.Status = 'NotRelevant'
        $res.ResultMessage = 'Azure AD not connected. Please complete the Identity analytics server (Hybrid server) setup.'
        return $res
    }

    $getToken = @{
        TenantId = $TenantId
        TenantAppId = $TenantAppId
        TenantAppSecret = $TenantAppSecret
    }

    $graphAccess = Get-GraphApiToken @getToken

    $getAuthorizationPolicies = @{
        Uri = "https://graph.microsoft.com/beta/policies/authorizationPolicy"
        AccessToken = $graphAccess
    }

    try {
        $authorizationPolicies = Invoke-GraphApiRequest @getAuthorizationPolicies
    }
    catch {
        return $_ | ConvertTo-GraphApiErrorResult -RequiredPrivileges 'Read Authorization Policy' -TenantAppId $TenantAppId -AccessToken $graphAccess
    }

    if ($authorizationPolicies.value.defaultUserRolePermissions.allowedToCreateTenants -eq $true) {
        $res.Score = 0
        $res.ResultMessage = $self.ResultMessage
        $res.Remediation = $self.Remediation
        $res.Status = [Semperis.PSSecurityIndicatorResult.ScriptStatus]"Failed"

    }
    else {
        $res.Score = 100
        $res.ResultMessage = "No evidence of exposure."
        $res.Remediation = "None"
        $res.Status = [Semperis.PSSecurityIndicatorResult.ScriptStatus]"Pass"
    }
}
catch {
    return ConvertTo-ErrorResult $_
}
return $res

# SIG # Begin signature block
# MIItlwYJKoZIhvcNAQcCoIItiDCCLYQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB+qW1OVCy2G/wl
# W8M/wdp0Tr5Rtjf1BWcO902LhVamn6CCJrcwggWNMIIEdaADAgECAhAOmxiO+dAt
# 5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBa
# Fw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3E
# MB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKy
# unWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsF
# xl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU1
# 5zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJB
# MtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObUR
# WBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6
# nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxB
# YKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5S
# UUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+x
# q4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIB
# NjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMC
# AYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0Nc
# Vec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnov
# Lbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65Zy
# oUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFW
# juyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPF
# mCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9z
# twGpn1eqXijiuZQwggWiMIIEiqADAgECAhB4AxhCRXCKQc9vAbjutKlUMA0GCSqG
# SIb3DQEBDAUAMEwxIDAeBgNVBAsTF0dsb2JhbFNpZ24gUm9vdCBDQSAtIFIzMRMw
# EQYDVQQKEwpHbG9iYWxTaWduMRMwEQYDVQQDEwpHbG9iYWxTaWduMB4XDTIwMDcy
# ODAwMDAwMFoXDTI5MDMxODAwMDAwMFowUzELMAkGA1UEBhMCQkUxGTAXBgNVBAoT
# EEdsb2JhbFNpZ24gbnYtc2ExKTAnBgNVBAMTIEdsb2JhbFNpZ24gQ29kZSBTaWdu
# aW5nIFJvb3QgUjQ1MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAti3F
# MN166KuQPQNysDpLmRZhsuX/pWcdNxzlfuyTg6qE9aNDm5hFirhjV12bAIgEJen4
# aJJLgthLyUoD86h/ao+KYSe9oUTQ/fU/IsKjT5GNswWyKIKRXftZiAULlwbCmPgs
# pzMk7lA6QczwoLB7HU3SqFg4lunf+RuRu4sQLNLHQx2iCXShgK975jMKDFlrjrz0
# q1qXe3+uVfuE8ID+hEzX4rq9xHWhb71hEHREspgH4nSr/2jcbCY+6R/l4ASHrTDT
# DI0DfFW4FnBcJHggJetnZ4iruk40mGtwEd44ytS+ocCc4d8eAgHYO+FnQ4S2z/x0
# ty+Eo7+6CTc9Z2yxRVwZYatBg/WsHet3DUZHc86/vZWV7Z0riBD++ljop1fhs8+o
# WukHJZsSxJ6Acj2T3IyU3ztE5iaA/NLDA/CMDNJF1i7nj5ie5gTuQm5nfkIWcWLn
# BPlgxmShtpyBIU4rxm1olIbGmXRzZzF6kfLUjHlufKa7fkZvTcWFEivPmiJECKiF
# N84HYVcGFxIkwMQxc6GYNVdHfhA6RdktpFGQmKmgBzfEZRqqHGsWd/enl+w/GTCZ
# bzH76kCy59LE+snQ8FB2dFn6jW0XMr746X4D9OeHdZrUSpEshQMTAitCgPKJajbP
# yEygzp74y42tFqfT3tWbGKfGkjrxgmPxLg4kZN8CAwEAAaOCAXcwggFzMA4GA1Ud
# DwEB/wQEAwIBhjATBgNVHSUEDDAKBggrBgEFBQcDAzAPBgNVHRMBAf8EBTADAQH/
# MB0GA1UdDgQWBBQfAL9GgAr8eDm3pbRD2VZQu86WOzAfBgNVHSMEGDAWgBSP8Et/
# qC5FJK5NUPpjmove4t0bvDB6BggrBgEFBQcBAQRuMGwwLQYIKwYBBQUHMAGGIWh0
# dHA6Ly9vY3NwLmdsb2JhbHNpZ24uY29tL3Jvb3RyMzA7BggrBgEFBQcwAoYvaHR0
# cDovL3NlY3VyZS5nbG9iYWxzaWduLmNvbS9jYWNlcnQvcm9vdC1yMy5jcnQwNgYD
# VR0fBC8wLTAroCmgJ4YlaHR0cDovL2NybC5nbG9iYWxzaWduLmNvbS9yb290LXIz
# LmNybDBHBgNVHSAEQDA+MDwGBFUdIAAwNDAyBggrBgEFBQcCARYmaHR0cHM6Ly93
# d3cuZ2xvYmFsc2lnbi5jb20vcmVwb3NpdG9yeS8wDQYJKoZIhvcNAQEMBQADggEB
# AKz3zBWLMHmoHQsoiBkJ1xx//oa9e1ozbg1nDnti2eEYXLC9E10dI645UHY3qkT9
# XwEjWYZWTMytvGQTFDCkIKjgP+icctx+89gMI7qoLao89uyfhzEHZfU5p1GCdeHy
# L5f20eFlloNk/qEdUfu1JJv10ndpvIUsXPpYd9Gup7EL4tZ3u6m0NEqpbz308w2V
# Xeb5ekWwJRcxLtv3D2jmgx+p9+XUnZiM02FLL8Mofnrekw60faAKbZLEtGY/fadY
# 7qz37MMIAas4/AocqcWXsojICQIZ9lyaGvFNbDDUswarAGBIDXirzxetkpNiIHd1
# bL3IMrTcTevZ38GQlim9wX8wggauMIIElqADAgECAhAHNje3JFR82Ees/ShmKl5b
# MA0GCSqGSIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMjAzMjMwMDAwMDBaFw0zNzAzMjIyMzU5
# NTlaMGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkG
# A1UEAxMyRGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3Rh
# bXBpbmcgQ0EwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDGhjUGSbPB
# PXJJUVXHJQPE8pE3qZdRodbSg9GeTKJtoLDMg/la9hGhRBVCX6SI82j6ffOciQt/
# nR+eDzMfUBMLJnOWbfhXqAJ9/UO0hNoR8XOxs+4rgISKIhjf69o9xBd/qxkrPkLc
# Z47qUT3w1lbU5ygt69OxtXXnHwZljZQp09nsad/ZkIdGAHvbREGJ3HxqV3rwN3mf
# XazL6IRktFLydkf3YYMZ3V+0VAshaG43IbtArF+y3kp9zvU5EmfvDqVjbOSmxR3N
# Ng1c1eYbqMFkdECnwHLFuk4fsbVYTXn+149zk6wsOeKlSNbwsDETqVcplicu9Yem
# j052FVUmcJgmf6AaRyBD40NjgHt1biclkJg6OBGz9vae5jtb7IHeIhTZgirHkr+g
# 3uM+onP65x9abJTyUpURK1h0QCirc0PO30qhHGs4xSnzyqqWc0Jon7ZGs506o9UD
# 4L/wojzKQtwYSH8UNM/STKvvmz3+DrhkKvp1KCRB7UK/BZxmSVJQ9FHzNklNiyDS
# LFc1eSuo80VgvCONWPfcYd6T/jnA+bIwpUzX6ZhKWD7TA4j+s4/TXkt2ElGTyYwM
# O1uKIqjBJgj5FBASA31fI7tk42PgpuE+9sJ0sj8eCXbsq11GdeJgo1gJASgADoRU
# 7s7pXcheMBK9Rp6103a50g5rmQzSM7TNsQIDAQABo4IBXTCCAVkwEgYDVR0TAQH/
# BAgwBgEB/wIBADAdBgNVHQ4EFgQUuhbZbU2FL3MpdpovdYxqII+eyG8wHwYDVR0j
# BBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0
# cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0
# cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8E
# PDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkUm9vdEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEw
# DQYJKoZIhvcNAQELBQADggIBAH1ZjsCTtm+YqUQiAX5m1tghQuGwGC4QTRPPMFPO
# vxj7x1Bd4ksp+3CKDaopafxpwc8dB+k+YMjYC+VcW9dth/qEICU0MWfNthKWb8RQ
# TGIdDAiCqBa9qVbPFXONASIlzpVpP0d3+3J0FNf/q0+KLHqrhc1DX+1gtqpPkWae
# LJ7giqzl/Yy8ZCaHbJK9nXzQcAp876i8dU+6WvepELJd6f8oVInw1YpxdmXazPBy
# oyP6wCeCRK6ZJxurJB4mwbfeKuv2nrF5mYGjVoarCkXJ38SNoOeY+/umnXKvxMfB
# wWpx2cYTgAnEtp/Nh4cku0+jSbl3ZpHxcpzpSwJSpzd+k1OsOx0ISQ+UzTl63f8l
# Y5knLD0/a6fxZsNBzU+2QJshIUDQtxMkzdwdeDrknq3lNHGS1yZr5Dhzq6YBT70/
# O3itTK37xJV77QpfMzmHQXh6OOmc4d0j/R0o08f56PGYX/sr2H7yRp11LB4nLCbb
# bxV7HhmLNriT1ObyF5lZynDwN7+YAN8gFk8n+2BnFqFmut1VwDophrCYoCvtlUG3
# OtUVmDG0YgkPCr2B2RP+v6TR81fZvAT6gt4y3wSJ8ADNXcL50CN/AAvkdgIm2fBl
# dkKmKYcJRyvmfxqkhQ/8mJb2VVQrH4D6wPIOK+XW+6kvRBVK5xMOHds3OBqhK/bt
# 1nz8MIIGwDCCBKigAwIBAgIQDE1pckuU+jwqSj0pB4A9WjANBgkqhkiG9w0BAQsF
# ADBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNV
# BAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1w
# aW5nIENBMB4XDTIyMDkyMTAwMDAwMFoXDTMzMTEyMTIzNTk1OVowRjELMAkGA1UE
# BhMCVVMxETAPBgNVBAoTCERpZ2lDZXJ0MSQwIgYDVQQDExtEaWdpQ2VydCBUaW1l
# c3RhbXAgMjAyMiAtIDIwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDP
# 7KUmOsap8mu7jcENmtuh6BSFdDMaJqzQHFUeHjZtvJJVDGH0nQl3PRWWCC9rZKT9
# BoMW15GSOBwxApb7crGXOlWvM+xhiummKNuQY1y9iVPgOi2Mh0KuJqTku3h4uXoW
# 4VbGwLpkU7sqFudQSLuIaQyIxvG+4C99O7HKU41Agx7ny3JJKB5MgB6FVueF7fJh
# vKo6B332q27lZt3iXPUv7Y3UTZWEaOOAy2p50dIQkUYp6z4m8rSMzUy5Zsi7qlA4
# DeWMlF0ZWr/1e0BubxaompyVR4aFeT4MXmaMGgokvpyq0py2909ueMQoP6McD1AG
# N7oI2TWmtR7aeFgdOej4TJEQln5N4d3CraV++C0bH+wrRhijGfY59/XBT3EuiQMR
# oku7mL/6T+R7Nu8GRORV/zbq5Xwx5/PCUsTmFntafqUlc9vAapkhLWPlWfVNL5Af
# J7fSqxTlOGaHUQhr+1NDOdBk+lbP4PQK5hRtZHi7mP2Uw3Mh8y/CLiDXgazT8QfU
# 4b3ZXUtuMZQpi+ZBpGWUwFjl5S4pkKa3YWT62SBsGFFguqaBDwklU/G/O+mrBw5q
# BzliGcnWhX8T2Y15z2LF7OF7ucxnEweawXjtxojIsG4yeccLWYONxu71LHx7jstk
# ifGxxLjnU15fVdJ9GSlZA076XepFcxyEftfO4tQ6dwIDAQABo4IBizCCAYcwDgYD
# VR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaA
# FLoW2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBRiit7QYfyPMRTtlwvNPSqU
# FN9SnDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3Js
# MIGQBggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0Eu
# Y3J0MA0GCSqGSIb3DQEBCwUAA4ICAQBVqioa80bzeFc3MPx140/WhSPx/PmVOZsl
# 5vdyipjDd9Rk/BX7NsJJUSx4iGNVCUY5APxp1MqbKfujP8DJAJsTHbCYidx48s18
# hc1Tna9i4mFmoxQqRYdKmEIrUPwbtZ4IMAn65C3XCYl5+QnmiM59G7hqopvBU2AJ
# 6KO4ndetHxy47JhB8PYOgPvk/9+dEKfrALpfSo8aOlK06r8JSRU1NlmaD1TSsht/
# fl4JrXZUinRtytIFZyt26/+YsiaVOBmIRBTlClmia+ciPkQh0j8cwJvtfEiy2JIM
# kU88ZpSvXQJT657inuTTH4YBZJwAwuladHUNPeF5iL8cAZfJGSOA1zZaX5YWsWMM
# xkZAO85dNdRZPkOaGK7DycvD+5sTX2q1x+DzBcNZ3ydiK95ByVO5/zQQZ/YmMph7
# /lxClIGUgp2sCovGSxVK05iQRWAzgOAj3vgDpPZFR+XOuANCR+hBNnF3rf2i6Jd0
# Ti7aHh2MWsgemtXC8MYiqE+bvdgcmlHEL5r2X6cnl7qWLoVXwGDneFZ/au/ClZpL
# EQLIgpzJGgV8unG1TnqZbPTontRamMifv427GFxD9dAq6OJi7ngE273R+1sKqHB+
# 8JeEeOMIA11HLGOoJTiXAdI/Otrl5fbmm9x+LMz/F0xNAKLY1gEOuIvu5uByVYks
# Jxlh9ncBjDCCBuYwggTOoAMCAQICEHe9DgOhtwj4VKsGchDZBEcwDQYJKoZIhvcN
# AQELBQAwUzELMAkGA1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2Ex
# KTAnBgNVBAMTIEdsb2JhbFNpZ24gQ29kZSBTaWduaW5nIFJvb3QgUjQ1MB4XDTIw
# MDcyODAwMDAwMFoXDTMwMDcyODAwMDAwMFowWTELMAkGA1UEBhMCQkUxGTAXBgNV
# BAoTEEdsb2JhbFNpZ24gbnYtc2ExLzAtBgNVBAMTJkdsb2JhbFNpZ24gR0NDIFI0
# NSBDb2RlU2lnbmluZyBDQSAyMDIwMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEA1kJN+eNPxiP0bB2BpjD3SD3P0OWN5SAilgdENV0Gzw8dcGDmJlT6UyNg
# AqhfAgL3jsluPal4Bb2O9U8ZJJl8zxEWmx97a9Kje2hld6vYsSw/03IGMlxbrFBn
# LCVNVgY2/MFiTH19hhaVml1UulDQsH+iRBnp1m5sPhPCnxHUXzRbUWgxYwr4W9De
# ullfMa+JaDhAPgjoU2dOY7Yhju/djYVBVZ4cvDfclaDEcacfG6VJbgogWX6Jo1gV
# lwAlad/ewmpQZU5T+2uhnxgeig5fVF694FvP8gwE0t4IoRAm97Lzei7CjpbBP86l
# 2vRZKIw3ZaExlguOpHZ3FUmEZoIl50MKd1KxmVFC/6Gy3ZzS3BjZwYapQB1Bl2KG
# vKj/osdjFwb9Zno2lAEgiXgfkPR7qVJOak9UBiqAr57HUEL6ZQrjAfSxbqwOqOOB
# Gag4yJ4DKIakdKdHlX5yWip7FWocxGnmsL5AGZnL0n1VTiKcEOChW8OzLnqLxN7x
# Sx+MKHkwRX9sE7Y9LP8tSooq7CgPLcrUnJiKSm1aNiwv37rL4kFKCHcYiK01YZQS
# 86Ry6+42nqdRJ5E896IazPyH5ZfhUYdp6SLMg8C3D0VsB+FDT9SMSs7PY7G1pBB6
# +Q0MKLBrNP4haCdv7Pj6JoRbdULNiSZ5WZ1rq2NxYpAlDQgg8f8CAwEAAaOCAa4w
# ggGqMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggrBgEFBQcDAzASBgNVHRMB
# Af8ECDAGAQH/AgEAMB0GA1UdDgQWBBTas43AJJCja3fTDKBZ3SFnZHYLeDAfBgNV
# HSMEGDAWgBQfAL9GgAr8eDm3pbRD2VZQu86WOzCBkwYIKwYBBQUHAQEEgYYwgYMw
# OQYIKwYBBQUHMAGGLWh0dHA6Ly9vY3NwLmdsb2JhbHNpZ24uY29tL2NvZGVzaWdu
# aW5ncm9vdHI0NTBGBggrBgEFBQcwAoY6aHR0cDovL3NlY3VyZS5nbG9iYWxzaWdu
# LmNvbS9jYWNlcnQvY29kZXNpZ25pbmdyb290cjQ1LmNydDBBBgNVHR8EOjA4MDag
# NKAyhjBodHRwOi8vY3JsLmdsb2JhbHNpZ24uY29tL2NvZGVzaWduaW5ncm9vdHI0
# NS5jcmwwVgYDVR0gBE8wTTBBBgkrBgEEAaAyATIwNDAyBggrBgEFBQcCARYmaHR0
# cHM6Ly93d3cuZ2xvYmFsc2lnbi5jb20vcmVwb3NpdG9yeS8wCAYGZ4EMAQQBMA0G
# CSqGSIb3DQEBCwUAA4ICAQAIiHImxq/6rF8GwKqMkNrQssCil/9uEzIWVP0+9DAR
# n4+Y+ZtS3fKiFu7ZeJWmmnxhuAS1+OvL9GERM/ZlJbcRQovYaW7H/5W0gUOpfq6/
# gtZNzBGjg3FqEF4ZBafnbH9W9Khcw04JrVlruPl+pS64/N4OwqD7sATUExvHJ6m5
# qi0xO89GTJ3rTOy8Lpzxh6N/OGlfQUBn9lN96kHvjj37qdQROEbfPOv2zSK9E83w
# 4eblM6C+POR41RvMIPIwc7AiHPaE1ptcAALhKFJL/xJLQOrusBoGBp6E5ufw24RG
# +3PZK0K2yVc0xxbApushuaoO9/7byuu8F8u4Z+vjPk/bqZSGZFXJCQrA2QRxShFL
# WmTDvHh4rUxHJmUHmdXNNmChM1Oz9nsq1YlAPHGlq/iZWf3jm5JL3QW9Cwx4BivP
# U9i9EppbJ4aFP5G+4HiAc1Tfpx1nK2q2rk2JgCQIUnBQ8wH/RK4vmuDhSQjh4VvX
# ONGeCoqdlCebyqO52+I2auNvuVhi4DZ4NgH6waeJeiZTo1y70rLristjCC/+HvNW
# KeI1m9j/6aW9bUtZLIksL1K7tSmQ2kNHvHLdvNm/gMHcsKu0Sx1YNjdk65vhhRea
# KaL95gjSkv+g+Hzh6afRMI5fJlArx6Lil3eK79hNPibrmUBg8zxnDLYIcik1U4E0
# 3DCCBxwwggUEoAMCAQICDElF7GllQBbooYM+/DANBgkqhkiG9w0BAQsFADBZMQsw
# CQYDVQQGEwJCRTEZMBcGA1UEChMQR2xvYmFsU2lnbiBudi1zYTEvMC0GA1UEAxMm
# R2xvYmFsU2lnbiBHQ0MgUjQ1IENvZGVTaWduaW5nIENBIDIwMjAwHhcNMjIwMzAy
# MTE0ODM5WhcNMjQwNjE0MTQzMDQ0WjCBiTELMAkGA1UEBhMCVVMxETAPBgNVBAgT
# CE5ldyBZb3JrMREwDwYDVQQHEwhOZXcgWW9yazEWMBQGA1UEChMNU0VNUEVSSVMg
# SU5DLjEWMBQGA1UEAxMNU0VNUEVSSVMgSU5DLjEkMCIGCSqGSIb3DQEJARYVY29k
# ZXNpZ25Ac2VtcGVyaXMuY29tMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKC
# AgEAr6tl3SlmfsaiEOfMdtp4zvTErHoof7dk7J3pCnooplIEiChxu0y8qc9lcdPj
# 7pr8RJvSbG110CsfV6GzWevZUVJWmQqvE4mugzLxhFABL4t0r8HZSSa/gKMEndXr
# 3SUhwdbLmg38F+yuzyGoiHY55ecMHPWoz89tBYlezlISI2C0+E/RQC8/c8STflpX
# FCVEpqFwJnY1x5rz+jEDTu8ITyNmrhb66uzogNTdgsl0xasM9TpE5VKrWSLAg37i
# Frj0GRjwd/pzTfO3tXhH4zt728F04HuuPf+3F3ETLhSsrk1lBNwMV+UBVjPJrVro
# 1brvEHn7D88BicGkT/qFh0+R5jUu7O8BJ+/g4IHp4yKOtp/Ockp05Yi6H45fX35c
# QddB6twWIFbGcjRGAadYUSkacUOfGRzAJKQOJYmN3ISOJJT1hoHCFtR9sqjN0pQa
# 2k1bk/bJGmTrmt7uUPJ5Ucnl1qHgZkPD5R9ERXXjZ00cX5mOx5l0gpxvg+01R4cy
# TyxgRzAuBU46q6P8ESh4hiyJM+nnao8+eE8Sr/VN/VC7CCtLEGWl2/Ek1KeniiuZ
# SrdMFnnaI0G4tqqG97mSIBoPuKwBCk+FpvGXQ8u3jd2mU8P4uZo4hH8Mib4L81k/
# 8oSc+vmQzEBiBSY/S9g2j51EnoyzAuyvJMmcCVF1Rp9TUU0CAwEAAaOCAbEwggGt
# MA4GA1UdDwEB/wQEAwIHgDCBmwYIKwYBBQUHAQEEgY4wgYswSgYIKwYBBQUHMAKG
# Pmh0dHA6Ly9zZWN1cmUuZ2xvYmFsc2lnbi5jb20vY2FjZXJ0L2dzZ2NjcjQ1Y29k
# ZXNpZ25jYTIwMjAuY3J0MD0GCCsGAQUFBzABhjFodHRwOi8vb2NzcC5nbG9iYWxz
# aWduLmNvbS9nc2djY3I0NWNvZGVzaWduY2EyMDIwMFYGA1UdIARPME0wQQYJKwYB
# BAGgMgEyMDQwMgYIKwYBBQUHAgEWJmh0dHBzOi8vd3d3Lmdsb2JhbHNpZ24uY29t
# L3JlcG9zaXRvcnkvMAgGBmeBDAEEATAJBgNVHRMEAjAAMEUGA1UdHwQ+MDwwOqA4
# oDaGNGh0dHA6Ly9jcmwuZ2xvYmFsc2lnbi5jb20vZ3NnY2NyNDVjb2Rlc2lnbmNh
# MjAyMC5jcmwwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHwYDVR0jBBgwFoAU2rONwCSQ
# o2t30wygWd0hZ2R2C3gwHQYDVR0OBBYEFHl2JYTkRF1JSD0dmaZEJrMSJ1pZMA0G
# CSqGSIb3DQEBCwUAA4ICAQC1QWVq8P2sWcGYHIPqTtMGIv6YV8RNYVDsS2nkSUsU
# xGGZO0GrGKDNn0epo1M1dXWtbECkivTrVA2x3Ku/yVysHHSliLbcL/QCPkbXT8hr
# 3s71X53tbAQp96iMSt/+RURXWH7bnBOCLfO1BeH9ua0uRYBpy3OYfuDEICowr4SN
# Rf2iY0wSoWZ85QsBlMgLLFymJln9Pjw8SYsVOYkwfMiv1aT7uCxVlkYtKW9bkmyb
# HuKiEduQwSfs5GzegSFM+WcfC4JqBhVXRBxQljX53Y1rb3eA8CVLTHZPVqXXM8di
# 628y1IylTdTzXcriFjCmMYZ0re+FNlVBT6KhJ+nP+pcSmrbVy9qg/BX1fQD5XGT6
# 3VdQp4qfTK25uWHWHm0GlOMR/SyC5HEmpASUkL5tHr+n+9GoRyS8IjQop37RJ1hK
# oBXlH0ayyQWHvLQjCM5Hx+ARSDq3HdeqK3ToAuUDJ+G5qgr0BP3X9Ap4K7fSn8p0
# gafpMdSBWRnmfIhPa0E4XEMA++XQtfy+gA4nr/0zD05uB+vpSli97phr6f3duafm
# NJbH40z7xlg2euTBd7CkUtI3KwFq0pvdgln0Xsjl5NhR4yY7Y9oQIjWd9ooFYWqx
# nphR9JecB3P+CkVA3L7Xwqu5PIXSZ+bPhF5a8yNNThYmm8g20dl3vCaZiX5/RHvt
# 8jGCBjYwggYyAgEBMGkwWTELMAkGA1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNp
# Z24gbnYtc2ExLzAtBgNVBAMTJkdsb2JhbFNpZ24gR0NDIFI0NSBDb2RlU2lnbmlu
# ZyBDQSAyMDIwAgxJRexpZUAW6KGDPvwwDQYJYIZIAWUDBAIBBQCgfDAQBgorBgEE
# AYI3AgEMMQIwADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3
# AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgiQdEq+ax/oEFm0l9
# Mgj+XKGv3WKsWaXHuwRDqt9V5J0wDQYJKoZIhvcNAQEBBQAEggIAHPu+NYbWbbyW
# NT3WSiyAElKX3bf/zgpXaqSGrKOvebGK5FreDQQ/EAz9S8beGQYll2vJ8ddkpgtv
# OT9EgYRIRjK6UPfohetlZcHdpviP/Cku+Bbc3eFDeMO5VjHAVQ5iotzmIPNywjnO
# aJoWayCrZpctdkIJSHyHcvJM6/mrLh8pSnlUs3ZvB3pi2hETir00OYrtW+B+ZadS
# O03yESlZrY9QU4ibv1Po5z7KyHtkUCf1hWk3L9xeTVy0sxDI+cIGhl37SjrXWUtZ
# VmTvFUxZjXMFdCN+e3HN5aLl9s1Q3DuqSuuBZpRHOzTjECsCXFOfKK8+Ip+b4mwh
# HWwPuJKdRQKm621GM6Tk47ulzHPMjcZacd/nTrK1U4BHxqLSBNWXNoX0ETrrzU6m
# IPU2TIA/Gy7sol9QiXM15BjCFLaMibs1OifHg9l+WNaG3qekLp8OoXQ5oaXSO63D
# zSBrsIMSkbQWTqWPj74jaZ6SfFetn0IxArCDKRpa1Bp7MjhtzCrkLFLahin7S9zi
# y5ovxSP0sV/5386sjYwAIMX34wiqfgnvrIA+UsN24n3vZAw3mukgk43EiOAIyOGl
# sB8JLqwOHwQbR+dDVIIVbg6NOQHi2kP47Ro2csGJe9ac/6uBOW8qub0U5I2mEAsZ
# DKn22eCfMjxSUnYtExU00MwsmhRF1pChggMgMIIDHAYJKoZIhvcNAQkGMYIDDTCC
# AwkCAQEwdzBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4x
# OzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGlt
# ZVN0YW1waW5nIENBAhAMTWlyS5T6PCpKPSkHgD1aMA0GCWCGSAFlAwQCAQUAoGkw
# GAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNjI2
# MTUyNTM0WjAvBgkqhkiG9w0BCQQxIgQgg9gb02Q+0BJtSPzhA41nX+4R9t9B8ReD
# Pz2HZAMk1O8wDQYJKoZIhvcNAQEBBQAEggIAwmhRIYQiyIs903w6FHoPb3V5RWQ6
# /5lXY/X1opB/8gQDAtTwzxTly11Jf5ZWfQcme8TGXBjVwn0awyyCnmEdj79f40Ui
# ESdeYeKD9ARfcy9qoWEDQqZrFGSjEQOr/U6AVFhqDtHDKi0jVh/KL1Cov3a/rGKx
# zpd3oCz1nVmShMOP2jSiY6aemsVgZ2rt1B1oS9dHL5MibMiIP9oEzbImXT2H7KnQ
# Kbp0flbx539iXOj0sGUBiUqZtllRDUOQrdzXS4NGdHFA5atS76msZg8kAdH/W4wK
# SNhC+wa4kwCAuBF16O2Fbx4GPoVPZCU2Tqc3m5bl/bEXUaAW1iIk/qeuAAyjCx07
# wRu8gtXDh/eXT7v96dqoxlxjcRKqzrNnmHktog/9U7OrGJnGFCPDKeJl6axQPUTd
# 4D8wJe7wZ1ReTF4tb5W3p1VNvnexBIXWtF2joYd8EnMG1054EJB6vx6JgK9JplqR
# aP9qVttZ1Bechn8mdfbIUrxUHYVYnfD5ZSXjPSy04Va+pI9X+sgv/BkKSCX2XV2V
# PgqFlprXl5JZkqV2AO2EgYC0mNxXFLKK4LLSvwFOzKRLUTe6IRLjzvl3aZGTSKUq
# B8IBRgkctMk/WVvM6lbPTLZRqXU4+/VjEouWCNR4B5GP357mVB3+Z//gucoaq/QM
# qKdfOkc7bQektBM=
# SIG # End signature block
